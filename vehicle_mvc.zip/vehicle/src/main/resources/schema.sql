-- =============================================================
--  Vehicle Identification System  -  PostgreSQL Schema  v3.0
--  Run this script once on a fresh database.
--  Safe to re-run: uses IF NOT EXISTS and DROP IF EXISTS.
-- =============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ─────────────────────────────────────────────────────────────
--  DROP VIEWS (so we can recreate them cleanly)
-- ─────────────────────────────────────────────────────────────
DROP VIEW IF EXISTS vw_outstanding_violations CASCADE;
DROP VIEW IF EXISTS vw_service_history CASCADE;
DROP VIEW IF EXISTS vw_vehicle_full_details CASCADE;

-- ─────────────────────────────────────────────────────────────
--  TABLES
-- ─────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS Customer (
    customer_id   SERIAL PRIMARY KEY,
    name          VARCHAR(120) NOT NULL,
    address       VARCHAR(255),
    phone         VARCHAR(30),
    email         VARCHAR(120) UNIQUE
);

CREATE TABLE IF NOT EXISTS AppUser (
    user_id       VARCHAR(40)  PRIMARY KEY,
    password      VARCHAR(255) NOT NULL,
    role          VARCHAR(20)  NOT NULL CHECK (role IN ('ADMIN','WORKSHOP','CUSTOMER','POLICE','INSURANCE')),
    full_name     VARCHAR(120) NOT NULL,
    active        BOOLEAN      NOT NULL DEFAULT TRUE,
    customer_id   INT          REFERENCES Customer(customer_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS Vehicle (
    vehicle_id            SERIAL PRIMARY KEY,
    registration_number   VARCHAR(30)  NOT NULL UNIQUE,
    make                  VARCHAR(60)  NOT NULL,
    model                 VARCHAR(60)  NOT NULL,
    year                  INT          NOT NULL CHECK (year BETWEEN 1900 AND 2100),
    customer_id           INT          REFERENCES Customer(customer_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS ServiceRecord (
    service_id    SERIAL PRIMARY KEY,
    vehicle_id    INT  NOT NULL REFERENCES Vehicle(vehicle_id) ON DELETE CASCADE,
    service_date  DATE NOT NULL,
    service_type  VARCHAR(80) NOT NULL,
    description   TEXT,
    cost          NUMERIC(10,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS PoliceReport (
    report_id     SERIAL PRIMARY KEY,
    vehicle_id    INT  NOT NULL REFERENCES Vehicle(vehicle_id) ON DELETE CASCADE,
    report_date   DATE NOT NULL,
    report_type   VARCHAR(80) NOT NULL,
    description   TEXT,
    officer_name  VARCHAR(120)
);

CREATE TABLE IF NOT EXISTS Violation (
    violation_id    SERIAL PRIMARY KEY,
    vehicle_id      INT  NOT NULL REFERENCES Vehicle(vehicle_id) ON DELETE CASCADE,
    violation_date  DATE NOT NULL,
    violation_type  VARCHAR(80) NOT NULL,
    fine_amount     NUMERIC(10,2) NOT NULL DEFAULT 0,
    status          VARCHAR(20)   NOT NULL DEFAULT 'Unpaid' CHECK (status IN ('Paid','Unpaid'))
);

-- ─────────────────────────────────────────────────────────────
--  VIEWS
-- ─────────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW vw_vehicle_full_details AS
SELECT v.vehicle_id,
       v.registration_number,
       v.make,
       v.model,
       v.year,
       v.customer_id,
       c.name AS owner_name
FROM   Vehicle v
LEFT JOIN Customer c ON c.customer_id = v.customer_id;

CREATE OR REPLACE VIEW vw_service_history AS
SELECT sr.service_id,
       v.registration_number,
       sr.vehicle_id,
       sr.service_date,
       sr.service_type,
       sr.description,
       sr.cost
FROM   ServiceRecord sr
JOIN   Vehicle v ON v.vehicle_id = sr.vehicle_id;

CREATE OR REPLACE VIEW vw_outstanding_violations AS
SELECT vi.violation_id,
       vi.vehicle_id,
       v.registration_number,
       vi.violation_date,
       vi.violation_type,
       vi.fine_amount,
       vi.status
FROM   Violation vi
JOIN   Vehicle v ON v.vehicle_id = vi.vehicle_id
WHERE  vi.status = 'Unpaid';

-- ─────────────────────────────────────────────────────────────
--  STORED PROCEDURES
-- ─────────────────────────────────────────────────────────────

CREATE OR REPLACE PROCEDURE sp_add_vehicle(
    p_registration VARCHAR,
    p_make         VARCHAR,
    p_model        VARCHAR,
    p_year         INT,
    p_owner_id     INT
) LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO Vehicle(registration_number, make, model, year, customer_id)
    VALUES (p_registration, p_make, p_model, p_year, p_owner_id);
END;
$$;

CREATE OR REPLACE PROCEDURE sp_update_vehicle(
    p_vehicle_id   INT,
    p_registration VARCHAR,
    p_make         VARCHAR,
    p_model        VARCHAR,
    p_year         INT,
    p_owner_id     INT
) LANGUAGE plpgsql AS $$
BEGIN
    UPDATE Vehicle
    SET registration_number = p_registration,
        make    = p_make,
        model   = p_model,
        year    = p_year,
        customer_id = p_owner_id
    WHERE vehicle_id = p_vehicle_id;
END;
$$;

CREATE OR REPLACE PROCEDURE sp_register_service(
    p_vehicle_id   INT,
    p_date         DATE,
    p_type         VARCHAR,
    p_description  TEXT,
    p_cost         NUMERIC
) LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO ServiceRecord(vehicle_id, service_date, service_type, description, cost)
    VALUES (p_vehicle_id, p_date, p_type, p_description, p_cost);
END;
$$;

CREATE OR REPLACE PROCEDURE sp_update_service(
    p_service_id  INT,
    p_date        DATE,
    p_type        VARCHAR,
    p_description TEXT,
    p_cost        NUMERIC
) LANGUAGE plpgsql AS $$
BEGIN
    UPDATE ServiceRecord
    SET service_date  = p_date,
        service_type  = p_type,
        description   = p_description,
        cost          = p_cost
    WHERE service_id = p_service_id;
END;
$$;

CREATE OR REPLACE PROCEDURE sp_pay_violation(p_violation_id INT)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE Violation SET status = 'Paid' WHERE violation_id = p_violation_id;
END;
$$;

CREATE OR REPLACE PROCEDURE sp_register_user(
    p_user_id     VARCHAR,
    p_password    VARCHAR,
    p_role        VARCHAR,
    p_full_name   VARCHAR,
    p_address     VARCHAR,
    p_phone       VARCHAR,
    p_email       VARCHAR
) LANGUAGE plpgsql AS $$
DECLARE
    v_customer_id INT := NULL;
BEGIN
    IF p_role = 'CUSTOMER' THEN
        INSERT INTO Customer(name, address, phone, email)
        VALUES (p_full_name, p_address, p_phone, p_email)
        RETURNING customer_id INTO v_customer_id;
    END IF;
    INSERT INTO AppUser(user_id, password, role, full_name, active, customer_id)
    VALUES (p_user_id, p_password, p_role, p_full_name, TRUE, v_customer_id);
END;
$$;

-- ─────────────────────────────────────────────────────────────
--  SEED DATA
-- ─────────────────────────────────────────────────────────────

INSERT INTO Customer(name, address, phone, email) VALUES
  ('Thabo Mokoena',   '14 Kingsway, Maseru',     '0711234567', 'thabo@example.com'),
  ('Lineo Dlamini',   '5 Pioneer Rd, Maseru',    '0829876543', 'lineo@example.com'),
  ('Mpho Sithole',    '22 Cathedral Rd, Maseru', '0631112222', 'mpho@example.com')
ON CONFLICT DO NOTHING;

INSERT INTO AppUser(user_id, password, role, full_name, active, customer_id) VALUES
  ('admin',     'admin123',    'ADMIN',     'System Administrator',    TRUE, NULL),
  ('customer1', 'pass123',     'CUSTOMER',  'Thabo Mokoena',           TRUE, 1),
  ('customer2', 'pass123',     'CUSTOMER',  'Lineo Dlamini',           TRUE, 2),
  ('officer1',  'police123',   'POLICE',    'Sgt. J. Nkosi',           TRUE, NULL),
  ('insurer1',  'insure123',   'INSURANCE', 'SafeCover Insurance',     TRUE, NULL),
  ('workshop1', 'workshop123', 'WORKSHOP',  'AutoFix Workshop',        TRUE, NULL)
ON CONFLICT DO NOTHING;

INSERT INTO Vehicle(registration_number, make, model, year, customer_id) VALUES
  ('GP12ABCD', 'Toyota',  'Corolla', 2020, 1),
  ('WC34EFGH', 'Honda',   'Civic',   2019, 2),
  ('NP56IJKL', 'Ford',    'Ranger',  2021, 3),
  ('FS78MNOP', 'Nissan',  'Navara',  2022, 1),
  ('EC90QRST', 'Toyota',  'Hilux',   2018, 2)
ON CONFLICT DO NOTHING;

INSERT INTO ServiceRecord(vehicle_id, service_date, service_type, description, cost) VALUES
  (1, '2024-01-15', 'Oil Change',     'Full synthetic oil change',           650.00),
  (1, '2024-06-20', 'Brake Service',  'Front brake pads replaced',          1200.00),
  (2, '2024-03-10', 'Tyre Rotation',  'All four tyres rotated',              450.00),
  (3, '2024-07-05', 'Engine Service', 'Major 90 000 km service',            3500.00),
  (4, '2024-08-12', 'Oil Change',     'Oil and filter change',               700.00),
  (5, '2024-09-01', 'Suspension',     'Front struts and shocks replaced',   2800.00)
ON CONFLICT DO NOTHING;

INSERT INTO PoliceReport(vehicle_id, report_date, report_type, description, officer_name) VALUES
  (2, '2024-02-14', 'Accident',       'Minor rear-end collision on N1',      'Sgt. J. Nkosi'),
  (3, '2024-05-22', 'Theft Attempt',  'Attempted vehicle theft reported',    'Cpl. P. Zulu'),
  (1, '2024-09-10', 'Accident',       'Side swipe in parking lot',           'Officer Thabo Mokoena'),
  (4, '2024-10-03', 'Vehicle Check',  'Random vehicle roadworthiness check', 'Officer Lebohang Phiri')
ON CONFLICT DO NOTHING;

INSERT INTO Violation(vehicle_id, violation_date, violation_type, fine_amount, status) VALUES
  (1, '2024-04-01', 'Speeding',           500.00, 'Paid'),
  (2, '2024-06-15', 'Illegal Parking',    350.00, 'Unpaid'),
  (3, '2024-07-20', 'Running Red Light',  750.00, 'Unpaid'),
  (4, '2024-08-05', 'Speeding',           600.00, 'Unpaid'),
  (5, '2024-09-18', 'No Seat Belt',       200.00, 'Paid')
ON CONFLICT DO NOTHING;
