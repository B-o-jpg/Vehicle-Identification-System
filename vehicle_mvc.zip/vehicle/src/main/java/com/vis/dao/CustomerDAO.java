package com.vis.dao;

  import com.vis.model.Customer;
  import java.sql.*;
import java.sql.Date;
  import java.util.*;

  public class CustomerDAO {

      public List<Customer> findAll() throws SQLException {
          List<Customer> list = new ArrayList<>();
          String sql = "SELECT customer_id,name,address,phone,email FROM Customer ORDER BY customer_id";
          try (Connection c = DatabaseConnection.getConnection();
               Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
              while (rs.next()) list.add(map(rs));
          }
          return list;
      }

      public Optional<Customer> findById(int customerId) throws SQLException {
          String sql = "SELECT customer_id,name,address,phone,email FROM Customer WHERE customer_id=?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, customerId);
              try (ResultSet rs = ps.executeQuery()) {
                  if (rs.next()) return Optional.of(map(rs));
              }
          }
          return Optional.empty();
      }

      public void create(Customer c) throws SQLException {
          String sql = "INSERT INTO Customer(name,address,phone,email) VALUES(?,?,?,?)";
          try (Connection conn = DatabaseConnection.getConnection();
               PreparedStatement ps = conn.prepareStatement(sql)) {
              ps.setString(1, c.getName()); ps.setString(2, c.getAddress());
              ps.setString(3, c.getPhone()); ps.setString(4, c.getEmail());
              ps.executeUpdate();
          }
      }

      public void update(Customer c) throws SQLException {
          String sql = "UPDATE Customer SET name=?,address=?,phone=?,email=? WHERE customer_id=?";
          try (Connection conn = DatabaseConnection.getConnection();
               PreparedStatement ps = conn.prepareStatement(sql)) {
              ps.setString(1, c.getName()); ps.setString(2, c.getAddress());
              ps.setString(3, c.getPhone()); ps.setString(4, c.getEmail());
              ps.setInt(5, c.getId()); ps.executeUpdate();
          }
      }

      public void delete(int customerId) throws SQLException {
          String sql = "DELETE FROM Customer WHERE customer_id=?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, customerId); ps.executeUpdate();
          }
      }

      private Customer map(ResultSet rs) throws SQLException {
          return new Customer(rs.getInt("customer_id"), rs.getString("name"),
                  rs.getString("address"), rs.getString("phone"), rs.getString("email"));
      }
  }
  