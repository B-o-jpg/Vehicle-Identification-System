package com.vis.dao;

  import com.vis.model.AppUser;
  import java.sql.*;
import java.sql.Date;
  import java.util.*;

  public class AppUserDAO {

      public Optional<AppUser> authenticate(String userId, String password) throws SQLException {
          String sql = "SELECT user_id,full_name,role,active,customer_id FROM AppUser " +
                       "WHERE user_id=? AND password=? AND active=TRUE";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setString(1, userId); ps.setString(2, password);
              try (ResultSet rs = ps.executeQuery()) {
                  if (rs.next()) return Optional.of(map(rs));
              }
          }
          return Optional.empty();
      }

      public List<AppUser> findAll() throws SQLException {
          List<AppUser> users = new ArrayList<>();
          String sql = "SELECT user_id,full_name,role,active,customer_id FROM AppUser ORDER BY user_id";
          try (Connection c = DatabaseConnection.getConnection();
               Statement s = c.createStatement();
               ResultSet rs = s.executeQuery(sql)) {
              while (rs.next()) users.add(map(rs));
          }
          return users;
      }

      public void create(AppUser u, String password) throws SQLException {
          String sql = "INSERT INTO AppUser(user_id,password,role,full_name,active,customer_id) VALUES(?,?,?,?,?,?)";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setString(1, u.getUserId()); ps.setString(2, password);
              ps.setString(3, u.getRole().name()); ps.setString(4, u.getFullName());
              ps.setBoolean(5, u.isActive());
              if (u.getCustomerId() != null) ps.setInt(6, u.getCustomerId());
              else ps.setNull(6, Types.INTEGER);
              ps.executeUpdate();
          }
      }

      /**
       * Full registration via stored procedure:
       * creates Customer row (if CUSTOMER role) and AppUser atomically.
       */
      public void register(String userId, String password, String role, String fullName,
                           String address, String phone, String email) throws SQLException {
          String sql = "CALL sp_register_user(?,?,?,?,?,?,?)";
          try (Connection c = DatabaseConnection.getConnection();
               CallableStatement cs = c.prepareCall(sql)) {
              cs.setString(1, userId); cs.setString(2, password); cs.setString(3, role);
              cs.setString(4, fullName); cs.setString(5, address);
              cs.setString(6, phone);   cs.setString(7, email);
              cs.execute();
          }
      }

      public void update(AppUser u) throws SQLException {
          String sql = "UPDATE AppUser SET full_name=?,role=?,active=? WHERE user_id=?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setString(1, u.getFullName()); ps.setString(2, u.getRole().name());
              ps.setBoolean(3, u.isActive());   ps.setString(4, u.getUserId());
              ps.executeUpdate();
          }
      }

      public void delete(String userId) throws SQLException {
          String sql = "DELETE FROM AppUser WHERE user_id=?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setString(1, userId); ps.executeUpdate();
          }
      }

      public void setActive(String userId, boolean active) throws SQLException {
          String sql = "UPDATE AppUser SET active=? WHERE user_id=?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setBoolean(1, active); ps.setString(2, userId); ps.executeUpdate();
          }
      }

      private AppUser map(ResultSet rs) throws SQLException {
          Integer cid = (Integer) rs.getObject("customer_id");
          return new AppUser(rs.getString("user_id"), rs.getString("full_name"),
                  AppUser.Role.valueOf(rs.getString("role")), rs.getBoolean("active"), cid);
      }
  }
  