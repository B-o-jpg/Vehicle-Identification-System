package com.vis.dao;

  import java.io.IOException;
  import java.io.InputStream;
  import java.sql.Connection;
  import java.sql.DriverManager;
  import java.sql.SQLException;
  import java.util.Properties;

  public final class DatabaseConnection {
      private static String url;
      private static String user;
      private static String password;

      static {
          Properties props = new Properties();
          try (InputStream in = DatabaseConnection.class.getResourceAsStream("/db.properties")) {
              if (in != null) {
                  props.load(in);
                  url      = props.getProperty("db.url",      "jdbc:postgresql://localhost:5432/vis_db");
                  user     = props.getProperty("db.user",     "postgres");
                  password = props.getProperty("db.password", "BOITUMELO");
              } else {
                  url = "jdbc:postgresql://localhost:5432/vis_db"; user = "postgres"; password = "BOITUMELO";
              }
          } catch (IOException ex) {
              url = "jdbc:postgresql://localhost:5432/vis_db"; user = "postgres"; password = "BOITUMELO";
          }
          try { Class.forName("org.postgresql.Driver"); } catch (ClassNotFoundException e) { /* ignored */ }
      }
      private DatabaseConnection() {}
      public static Connection getConnection() throws SQLException {
          return DriverManager.getConnection(url, user, password);
      }
  }
  