package com.vis.dao;

  import com.vis.model.Violation;
  import java.sql.*;
  import java.sql.Date;
  import java.time.LocalDate;
  import java.util.*;

  public class ViolationDAO {

      public List<Violation> findAll() throws SQLException {
          List<Violation> list = new ArrayList<>();
          String sql = "SELECT vi.violation_id, vi.vehicle_id, v.registration_number, " +
                       "vi.violation_date, vi.violation_type, vi.fine_amount, vi.status " +
                       "FROM Violation vi JOIN Vehicle v ON v.vehicle_id = vi.vehicle_id " +
                       "ORDER BY vi.violation_date DESC";
          try (Connection c = DatabaseConnection.getConnection();
               Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
              while (rs.next()) list.add(map(rs));
          }
          return list;
      }

      public List<Violation> findByCustomer(int customerId) throws SQLException {
          List<Violation> list = new ArrayList<>();
          String sql = "SELECT vi.violation_id, vi.vehicle_id, v.registration_number, " +
                       "vi.violation_date, vi.violation_type, vi.fine_amount, vi.status " +
                       "FROM Violation vi JOIN Vehicle v ON v.vehicle_id = vi.vehicle_id " +
                       "WHERE v.customer_id = ? ORDER BY vi.violation_date DESC";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, customerId);
              try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
          }
          return list;
      }

      /** Directly query unpaid violations — no view dependency. */
      public List<Violation> findUnpaid() throws SQLException {
          List<Violation> list = new ArrayList<>();
          String sql = "SELECT vi.violation_id, vi.vehicle_id, v.registration_number, " +
                       "vi.violation_date, vi.violation_type, vi.fine_amount, vi.status " +
                       "FROM Violation vi JOIN Vehicle v ON v.vehicle_id = vi.vehicle_id " +
                       "WHERE vi.status = 'Unpaid' ORDER BY vi.violation_date DESC";
          try (Connection c = DatabaseConnection.getConnection();
               Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
              while (rs.next()) list.add(map(rs));
          }
          return list;
      }

      public void create(int vehicleId, LocalDate date, String type, double fine, String status) throws SQLException {
          String sql = "INSERT INTO Violation(vehicle_id, violation_date, violation_type, fine_amount, status) " +
                       "VALUES (?, ?, ?, ?, ?)";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, vehicleId); ps.setDate(2, Date.valueOf(date));
              ps.setString(3, type); ps.setDouble(4, fine); ps.setString(5, status);
              ps.executeUpdate();
          }
      }

      public void update(Violation v) throws SQLException {
          String sql = "UPDATE Violation SET vehicle_id = ?, violation_date = ?, violation_type = ?, " +
                       "fine_amount = ?, status = ? WHERE violation_id = ?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, v.getVehicleId()); ps.setDate(2, Date.valueOf(v.getViolationDate()));
              ps.setString(3, v.getViolationType()); ps.setDouble(4, v.getFineAmount());
              ps.setString(5, v.getStatus()); ps.setInt(6, v.getViolationId());
              ps.executeUpdate();
          }
      }

      public void delete(int violationId) throws SQLException {
          String sql = "DELETE FROM Violation WHERE violation_id = ?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, violationId); ps.executeUpdate();
          }
      }

      public void payViolation(int violationId) throws SQLException {
          String sql = "UPDATE Violation SET status = 'Paid' WHERE violation_id = ?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, violationId); ps.executeUpdate();
          }
      }

      private Violation map(ResultSet rs) throws SQLException {
          Violation v = new Violation();
          v.setViolationId(rs.getInt("violation_id"));
          v.setVehicleId(rs.getInt("vehicle_id"));
          v.setRegistrationNumber(rs.getString("registration_number"));
          Date d = rs.getDate("violation_date"); if (d != null) v.setViolationDate(d.toLocalDate());
          v.setViolationType(rs.getString("violation_type"));
          v.setFineAmount(rs.getDouble("fine_amount"));
          v.setStatus(rs.getString("status"));
          return v;
      }
  }
