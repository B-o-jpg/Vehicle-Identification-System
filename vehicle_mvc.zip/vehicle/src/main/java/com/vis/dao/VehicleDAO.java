package com.vis.dao;

  import com.vis.model.Vehicle;
  import java.sql.*;
  import java.util.*;

  public class VehicleDAO {

      public List<Vehicle> findAll() throws SQLException {
          List<Vehicle> list = new ArrayList<>();
          String sql = "SELECT v.vehicle_id, v.registration_number, v.make, v.model, v.year, " +
                       "v.customer_id, c.name AS owner_name " +
                       "FROM Vehicle v LEFT JOIN Customer c ON c.customer_id = v.customer_id " +
                       "ORDER BY v.vehicle_id";
          try (Connection c2 = DatabaseConnection.getConnection();
               Statement s = c2.createStatement(); ResultSet rs = s.executeQuery(sql)) {
              while (rs.next()) list.add(map(rs));
          }
          return list;
      }

      public List<Vehicle> findByCustomer(int customerId) throws SQLException {
          List<Vehicle> list = new ArrayList<>();
          String sql = "SELECT v.vehicle_id, v.registration_number, v.make, v.model, v.year, " +
                       "v.customer_id, c.name AS owner_name " +
                       "FROM Vehicle v LEFT JOIN Customer c ON c.customer_id = v.customer_id " +
                       "WHERE v.customer_id = ? ORDER BY v.vehicle_id";
          try (Connection conn = DatabaseConnection.getConnection();
               PreparedStatement ps = conn.prepareStatement(sql)) {
              ps.setInt(1, customerId);
              try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
          }
          return list;
      }

      public Optional<Vehicle> findByRegistration(String reg) throws SQLException {
          String sql = "SELECT v.vehicle_id, v.registration_number, v.make, v.model, v.year, " +
                       "v.customer_id, c.name AS owner_name " +
                       "FROM Vehicle v LEFT JOIN Customer c ON c.customer_id = v.customer_id " +
                       "WHERE v.registration_number = ?";
          try (Connection conn = DatabaseConnection.getConnection();
               PreparedStatement ps = conn.prepareStatement(sql)) {
              ps.setString(1, reg);
              try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return Optional.of(map(rs)); }
          }
          return Optional.empty();
      }

      public void addVehicle(String reg, String make, String model, int year, Integer ownerId) throws SQLException {
          String sql = "INSERT INTO Vehicle(registration_number, make, model, year, customer_id) " +
                       "VALUES (?, ?, ?, ?, ?)";
          try (Connection conn = DatabaseConnection.getConnection();
               PreparedStatement ps = conn.prepareStatement(sql)) {
              ps.setString(1, reg); ps.setString(2, make); ps.setString(3, model); ps.setInt(4, year);
              if (ownerId == null || ownerId == 0) ps.setNull(5, Types.INTEGER);
              else ps.setInt(5, ownerId);
              ps.executeUpdate();
          }
      }

      public void update(Vehicle v) throws SQLException {
          String sql = "UPDATE Vehicle SET registration_number = ?, make = ?, model = ?, year = ?, " +
                       "customer_id = ? WHERE vehicle_id = ?";
          try (Connection conn = DatabaseConnection.getConnection();
               PreparedStatement ps = conn.prepareStatement(sql)) {
              ps.setString(1, v.getRegistrationNumber()); ps.setString(2, v.getMake());
              ps.setString(3, v.getModel()); ps.setInt(4, v.getYear());
              if (v.getOwnerId() == 0) ps.setNull(5, Types.INTEGER); else ps.setInt(5, v.getOwnerId());
              ps.setInt(6, v.getVehicleId());
              ps.executeUpdate();
          }
      }

      public void delete(int vehicleId) throws SQLException {
          String sql = "DELETE FROM Vehicle WHERE vehicle_id = ?";
          try (Connection conn = DatabaseConnection.getConnection();
               PreparedStatement ps = conn.prepareStatement(sql)) {
              ps.setInt(1, vehicleId); ps.executeUpdate();
          }
      }

      private Vehicle map(ResultSet rs) throws SQLException {
          return new Vehicle(
              rs.getInt("vehicle_id"),
              rs.getString("registration_number"),
              rs.getString("make"),
              rs.getString("model"),
              rs.getInt("year"),
              rs.getInt("customer_id"),
              rs.getString("owner_name")
          );
      }
  }
