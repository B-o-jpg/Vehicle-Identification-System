package com.vis.dao;

  import com.vis.model.ServiceRecord;
  import java.sql.*;
  import java.sql.Date;
  import java.time.LocalDate;
  import java.util.*;

  public class ServiceRecordDAO {

      public List<ServiceRecord> findAll() throws SQLException {
          List<ServiceRecord> list = new ArrayList<>();
          String sql = "SELECT sr.service_id, v.registration_number, sr.vehicle_id, " +
                       "sr.service_date, sr.service_type, sr.description, sr.cost " +
                       "FROM ServiceRecord sr JOIN Vehicle v ON v.vehicle_id = sr.vehicle_id " +
                       "ORDER BY sr.service_date DESC";
          try (Connection c = DatabaseConnection.getConnection();
               Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
              while (rs.next()) list.add(map(rs));
          }
          return list;
      }

      public List<ServiceRecord> findByCustomer(int customerId) throws SQLException {
          List<ServiceRecord> list = new ArrayList<>();
          String sql = "SELECT sr.service_id, v.registration_number, sr.vehicle_id, " +
                       "sr.service_date, sr.service_type, sr.description, sr.cost " +
                       "FROM ServiceRecord sr JOIN Vehicle v ON v.vehicle_id = sr.vehicle_id " +
                       "WHERE v.customer_id = ? ORDER BY sr.service_date DESC";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, customerId);
              try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
          }
          return list;
      }

      public void registerService(int vehicleId, LocalDate date, String type, String desc, double cost) throws SQLException {
          String sql = "INSERT INTO ServiceRecord(vehicle_id, service_date, service_type, description, cost) " +
                       "VALUES (?, ?, ?, ?, ?)";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, vehicleId); ps.setDate(2, Date.valueOf(date));
              ps.setString(3, type); ps.setString(4, desc); ps.setDouble(5, cost);
              ps.executeUpdate();
          }
      }

      public void update(ServiceRecord sr) throws SQLException {
          String sql = "UPDATE ServiceRecord SET vehicle_id = ?, service_date = ?, service_type = ?, " +
                       "description = ?, cost = ? WHERE service_id = ?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, sr.getVehicleId()); ps.setDate(2, Date.valueOf(sr.getServiceDate()));
              ps.setString(3, sr.getServiceType()); ps.setString(4, sr.getDescription());
              ps.setDouble(5, sr.getCost()); ps.setInt(6, sr.getServiceId());
              ps.executeUpdate();
          }
      }

      public void delete(int serviceId) throws SQLException {
          String sql = "DELETE FROM ServiceRecord WHERE service_id = ?";
          try (Connection c = DatabaseConnection.getConnection();
               PreparedStatement ps = c.prepareStatement(sql)) {
              ps.setInt(1, serviceId); ps.executeUpdate();
          }
      }

      private ServiceRecord map(ResultSet rs) throws SQLException {
          ServiceRecord r = new ServiceRecord();
          r.setServiceId(rs.getInt("service_id"));
          r.setVehicleId(rs.getInt("vehicle_id"));
          r.setRegistrationNumber(rs.getString("registration_number"));
          Date d = rs.getDate("service_date"); if (d != null) r.setServiceDate(d.toLocalDate());
          r.setServiceType(rs.getString("service_type"));
          r.setDescription(rs.getString("description"));
          r.setCost(rs.getDouble("cost"));
          return r;
      }
  }
