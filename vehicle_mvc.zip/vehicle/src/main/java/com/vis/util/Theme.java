package com.vis.util;

  import javafx.scene.control.Button;
  import javafx.scene.control.Label;
  import javafx.scene.layout.Region;
  import javafx.scene.paint.Color;
  import javafx.scene.text.Font;
  import javafx.scene.text.FontWeight;

  public final class Theme {

      public static final String FONT_FAMILY = "Segoe UI";

      public static final Color PRIMARY        = Color.web("#4F46E5");
      public static final Color PRIMARY_DARK   = Color.web("#1E1B4B");
      public static final Color PRIMARY_LIGHT  = Color.web("#818CF8");
      public static final Color ACCENT         = Color.web("#F59E0B");
      public static final Color ACCENT2        = Color.web("#06B6D4");
      public static final Color SUCCESS        = Color.web("#10B981");
      public static final Color WARNING        = Color.web("#F59E0B");
      public static final Color DANGER         = Color.web("#EF4444");
      public static final Color BG             = Color.web("#F0F0FF");
      public static final Color SURFACE        = Color.web("#FFFFFF");
      public static final Color BORDER         = Color.web("#C7D2FE");
      public static final Color TEXT           = Color.web("#1E1B4B");
      public static final Color TEXT_MUTED     = Color.web("#6B7280");
      public static final Color TEXT_ON_DARK   = Color.web("#EEF2FF");

      // All sidebars use the same indigo/violet palette — only depth differs
      public static final String SIDEBAR_ADMIN     = "-fx-background-color: linear-gradient(to bottom, #1E1B4B, #312E81, #4338CA);";
      public static final String SIDEBAR_CUSTOMER  = "-fx-background-color: linear-gradient(to bottom, #1E1B4B, #312E81, #4338CA);";
      public static final String SIDEBAR_POLICE    = "-fx-background-color: linear-gradient(to bottom, #1E1B4B, #312E81, #4338CA);";
      public static final String SIDEBAR_INSURANCE = "-fx-background-color: linear-gradient(to bottom, #1E1B4B, #312E81, #4338CA);";
      public static final String SIDEBAR_WORKSHOP  = "-fx-background-color: linear-gradient(to bottom, #1E1B4B, #312E81, #4338CA);";
      public static final String SIDEBAR_GRADIENT  = SIDEBAR_ADMIN;

      public static final String LOGIN_GRADIENT =
          "-fx-background-color: linear-gradient(to bottom right, #1E1B4B 0%, #4F46E5 55%, #818CF8 100%);";

      public static final String CARD_STYLE =
          "-fx-background-color: white;" +
          "-fx-background-radius: 14;" +
          "-fx-border-color: #C7D2FE;" +
          "-fx-border-radius: 14;" +
          "-fx-border-width: 1.5;" +
          "-fx-effect: dropshadow(gaussian, rgba(79,70,229,0.12), 18, 0, 0, 5);";

      public static final String STAT_CARD_STYLE =
          "-fx-background-color: linear-gradient(to bottom right, #4F46E5, #818CF8);" +
          "-fx-background-radius: 14;" +
          "-fx-effect: dropshadow(gaussian, rgba(79,70,229,0.30), 20, 0, 0, 6);";

      public static final String INPUT_STYLE =
          "-fx-background-color: #F5F3FF;" +
          "-fx-border-color: #A5B4FC;" +
          "-fx-border-radius: 8;" +
          "-fx-background-radius: 8;" +
          "-fx-padding: 9 13;" +
          "-fx-font-size: 13px;";

      public static final String TABLE_STYLE =
          "-fx-background-color: white;" +
          "-fx-border-color: #C7D2FE;" +
          "-fx-border-radius: 10;" +
          "-fx-background-radius: 10;";

      private Theme() {}

      public static String sidebarStyle(String role) {
          // All roles share the same indigo sidebar
          return SIDEBAR_ADMIN;
      }

      public static Label heading(String text, int size) {
          Label l = new Label(text);
          l.setFont(Font.font(FONT_FAMILY, FontWeight.BOLD, size));
          l.setTextFill(TEXT);
          return l;
      }

      public static Label subheading(String text) {
          Label l = new Label(text);
          l.setFont(Font.font(FONT_FAMILY, FontWeight.NORMAL, 13));
          l.setTextFill(TEXT_MUTED);
          return l;
      }

      public static Label pageTitle(String text) {
          Label l = new Label(text);
          l.setFont(Font.font(FONT_FAMILY, FontWeight.BOLD, 24));
          l.setTextFill(PRIMARY);
          return l;
      }

      public static Label badge(String text, String hex) {
          Label l = new Label("  " + text + "  ");
          l.setStyle("-fx-background-color:" + hex + "33; -fx-text-fill:" + hex +
                     "; -fx-background-radius:20; -fx-font-size:11px; -fx-font-weight:bold;");
          return l;
      }

      public static void primaryButton(Button b) {
          String base =
              "-fx-background-color: linear-gradient(to right, #4F46E5, #7C3AED);" +
              "-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 13px;" +
              "-fx-padding: 9 20; -fx-background-radius: 8; -fx-cursor: hand;" +
              "-fx-effect: dropshadow(gaussian,rgba(79,70,229,0.35),8,0,0,3);";
          String hover =
              "-fx-background-color: linear-gradient(to right, #6366F1, #8B5CF6);" +
              "-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 13px;" +
              "-fx-padding: 9 20; -fx-background-radius: 8; -fx-cursor: hand;" +
              "-fx-effect: dropshadow(gaussian,rgba(99,102,241,0.5),12,0,0,4);";
          b.setStyle(base);
          b.setOnMouseEntered(e -> b.setStyle(hover));
          b.setOnMouseExited(e -> b.setStyle(base));
      }

      public static void secondaryButton(Button b) {
          String base =
              "-fx-background-color: white; -fx-text-fill: #4F46E5;" +
              "-fx-font-weight: bold; -fx-font-size: 13px; -fx-padding: 9 20;" +
              "-fx-background-radius: 8; -fx-border-color: #A5B4FC; -fx-border-radius: 8; -fx-cursor: hand;";
          String hover =
              "-fx-background-color: #EEF2FF; -fx-text-fill: #4F46E5;" +
              "-fx-font-weight: bold; -fx-font-size: 13px; -fx-padding: 9 20;" +
              "-fx-background-radius: 8; -fx-border-color: #6366F1; -fx-border-radius: 8; -fx-cursor: hand;";
          b.setStyle(base);
          b.setOnMouseEntered(e -> b.setStyle(hover));
          b.setOnMouseExited(e -> b.setStyle(base));
      }

      public static void dangerButton(Button b) {
          String base =
              "-fx-background-color: linear-gradient(to right,#EF4444,#DC2626);" +
              "-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 13px;" +
              "-fx-padding: 9 20; -fx-background-radius: 8; -fx-cursor: hand;" +
              "-fx-effect: dropshadow(gaussian,rgba(239,68,68,0.3),8,0,0,3);";
          String hover =
              "-fx-background-color: linear-gradient(to right,#F87171,#EF4444);" +
              "-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 13px;" +
              "-fx-padding: 9 20; -fx-background-radius: 8; -fx-cursor: hand;" +
              "-fx-effect: dropshadow(gaussian,rgba(239,68,68,0.5),12,0,0,4);";
          b.setStyle(base);
          b.setOnMouseEntered(e -> b.setStyle(hover));
          b.setOnMouseExited(e -> b.setStyle(base));
      }

      public static void successButton(Button b) {
          String base =
              "-fx-background-color: linear-gradient(to right,#10B981,#059669);" +
              "-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 13px;" +
              "-fx-padding: 9 20; -fx-background-radius: 8; -fx-cursor: hand;" +
              "-fx-effect: dropshadow(gaussian,rgba(16,185,129,0.3),8,0,0,3);";
          b.setStyle(base);
          b.setOnMouseEntered(e -> b.setStyle(base.replace("0.3","0.5")));
          b.setOnMouseExited(e -> b.setStyle(base));
      }

      public static void warningButton(Button b) {
          String base =
              "-fx-background-color: linear-gradient(to right,#F59E0B,#D97706);" +
              "-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 13px;" +
              "-fx-padding: 9 20; -fx-background-radius: 8; -fx-cursor: hand;";
          b.setStyle(base);
      }

      public static Region spacer() { return new Region(); }
      public static Button btn(String text) { return new Button(text); }
  }
