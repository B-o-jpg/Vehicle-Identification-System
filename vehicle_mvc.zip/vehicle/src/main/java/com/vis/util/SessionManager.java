package com.vis.util;

  import com.vis.model.AppUser;

  public final class SessionManager {
      private static AppUser currentUser;
      private SessionManager() {}
      public static AppUser getCurrentUser()           { return currentUser; }
      public static void setCurrentUser(AppUser user)  { currentUser = user; }
      public static void clear()                       { currentUser = null; }

      public static boolean isAdmin()     { return currentUser != null && currentUser.getRole() == AppUser.Role.ADMIN; }
      public static boolean isCustomer()  { return currentUser != null && currentUser.getRole() == AppUser.Role.CUSTOMER; }
      public static boolean isPolice()    { return currentUser != null && currentUser.getRole() == AppUser.Role.POLICE; }
      public static boolean isInsurance() { return currentUser != null && currentUser.getRole() == AppUser.Role.INSURANCE; }
      public static boolean isWorkshop()  { return currentUser != null && currentUser.getRole() == AppUser.Role.WORKSHOP; }
  }
  