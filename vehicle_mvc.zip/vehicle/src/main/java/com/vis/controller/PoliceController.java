package com.vis.controller;
  import com.vis.dao.PoliceReportDAO;
  import com.vis.dao.VehicleDAO;
  import com.vis.model.*;
  import com.vis.util.*;
  import javafx.collections.*;
  import javafx.fxml.FXML;
  import javafx.fxml.Initializable;
  import javafx.geometry.Insets;
  import javafx.scene.control.*;
  import javafx.scene.control.cell.PropertyValueFactory;
  import java.net.URL;
  import java.sql.SQLException;
  import java.time.LocalDate;
  import java.util.*;
  public class PoliceController implements Initializable {
      @FXML private Label  pageTitle,pageSubtitle;
      @FXML private Button addBtn,editBtn,deleteBtn;
      @FXML private TableView<PoliceReport> table;
      @FXML private TableColumn<PoliceReport,Integer> colId,colVehicle;
      @FXML private TableColumn<PoliceReport,String>  colReg,colDate,colType,colDesc,colOfficer;
      private final PoliceReportDAO reportDAO=new PoliceReportDAO();
      private final ObservableList<PoliceReport> data=FXCollections.observableArrayList();
      @Override public void initialize(URL url, ResourceBundle rb) {
          boolean canEdit=SessionManager.isAdmin()||SessionManager.isPolice();
          pageTitle.setText(SessionManager.isCustomer()?"My Police Reports":"Police Reports");
          pageSubtitle.setText("Incident and accident reports");
          if(canEdit){addBtn.setVisible(true);addBtn.setManaged(true);editBtn.setVisible(true);editBtn.setManaged(true);deleteBtn.setVisible(true);deleteBtn.setManaged(true);}
          colId.setCellValueFactory(new PropertyValueFactory<>("reportId"));
          colVehicle.setCellValueFactory(new PropertyValueFactory<>("vehicleId"));
          colReg.setCellValueFactory(new PropertyValueFactory<>("registrationNumber"));
          colDate.setCellValueFactory(new PropertyValueFactory<>("reportDate"));
          colType.setCellValueFactory(new PropertyValueFactory<>("reportType"));
          colDesc.setCellValueFactory(new PropertyValueFactory<>("description"));
          colOfficer.setCellValueFactory(new PropertyValueFactory<>("officerName"));
          table.setItems(data); refresh();
      }
      public List<PoliceReport> getReports() throws SQLException { return reportDAO.findAll(); }
      public List<PoliceReport> getReportsByCustomer(int cid) throws SQLException { return reportDAO.findByCustomer(cid); }
      public void fileReport(int vehicleId,LocalDate date,String type,String desc,String officer) throws SQLException { reportDAO.create(vehicleId,date,type,desc,officer); }
      public void updateReport(PoliceReport r) throws SQLException { reportDAO.update(r); }
      public void deleteReport(int id) throws SQLException { reportDAO.delete(id); }
      @FXML public void handleAdd() { showForm(null); }
      @FXML public void handleEdit() {
          PoliceReport sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a report.");return;} showForm(sel);
      }
      @FXML public void handleDelete() {
          PoliceReport sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a report to delete.");return;}
          if(AlertUtil.confirm("Confirm","Delete report #"+sel.getReportId()+"?")){
              try{deleteReport(sel.getReportId());refresh();AlertUtil.info("Deleted","Report deleted.");}
              catch(SQLException ex){AlertUtil.error("Error",ex.getMessage());}
          }
      }
      private void showForm(PoliceReport existing) {
          boolean isEdit=existing!=null;
          Dialog<PoliceReport> dlg=new Dialog<>(); dlg.setTitle(isEdit?"Edit Report":"File Police Report");
          javafx.scene.layout.GridPane grid=new javafx.scene.layout.GridPane();
          grid.setHgap(10);grid.setVgap(10);grid.setPadding(new Insets(20));
          ComboBox<String> vehBox=vehicleCombo(isEdit?existing.getRegistrationNumber():null);
          Map<String,Integer> regToId=vehicleMap();
          DatePicker dp=new DatePicker(isEdit?existing.getReportDate():LocalDate.now());
          TextField tf=tf(isEdit?existing.getReportType():""),df=tf(isEdit?existing.getDescription():""),of=tf(isEdit?existing.getOfficerName():"");
          grid.addRow(0,new Label("Vehicle:"),vehBox);grid.addRow(1,new Label("Date:"),dp);
          grid.addRow(2,new Label("Type:"),tf);grid.addRow(3,new Label("Description:"),df);grid.addRow(4,new Label("Officer:"),of);
          dlg.getDialogPane().setContent(grid);
          dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
          dlg.setResultConverter(btn->{
              if(btn!=ButtonType.OK)return null;
              PoliceReport r=isEdit?existing:new PoliceReport();
              String sel=vehBox.getValue(); if(sel!=null)r.setVehicleId(regToId.getOrDefault(sel,0));
              r.setReportDate(dp.getValue());r.setReportType(tf.getText().trim());
              r.setDescription(df.getText().trim());r.setOfficerName(of.getText().trim()); return r;
          });
          dlg.showAndWait().ifPresent(r->{
              try{if(isEdit)updateReport(r);else fileReport(r.getVehicleId(),r.getReportDate(),r.getReportType(),r.getDescription(),r.getOfficerName());
                  refresh();AlertUtil.info("Success",isEdit?"Report updated.":"Report filed.");}
              catch(Exception e){AlertUtil.error("Error",e.getMessage());}
          });
      }
      private void refresh(){
          try{AppUser u=SessionManager.getCurrentUser();
              data.setAll((SessionManager.isCustomer()&&u.getCustomerId()!=null)?getReportsByCustomer(u.getCustomerId()):getReports());}
          catch(SQLException e){AlertUtil.error("DB Error",e.getMessage());}
      }
      private ComboBox<String> vehicleCombo(String sel){
          ComboBox<String> box=new ComboBox<>();
          try{for(Vehicle v:new VehicleDAO().findAll()){String l=v.getRegistrationNumber()+" ("+v.getMake()+" "+v.getModel()+")";box.getItems().add(l);if(sel!=null&&l.startsWith(sel))box.setValue(l);}}catch(SQLException e){}
          if(box.getValue()==null&&!box.getItems().isEmpty())box.setValue(box.getItems().get(0)); return box;
      }
      private Map<String,Integer> vehicleMap(){
          Map<String,Integer> m=new LinkedHashMap<>();
          try{for(Vehicle v:new VehicleDAO().findAll())m.put(v.getRegistrationNumber()+" ("+v.getMake()+" "+v.getModel()+")",v.getVehicleId());}catch(SQLException e){}
          return m;
      }
      private TextField tf(String v){TextField f=new TextField(v);f.setStyle(Theme.INPUT_STYLE);f.setPrefWidth(220);return f;}
  }