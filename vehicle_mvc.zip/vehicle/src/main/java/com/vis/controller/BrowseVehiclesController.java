package com.vis.controller;
  import com.vis.dao.VehicleDAO;
  import com.vis.model.Vehicle;
  import com.vis.util.AlertUtil;
  import javafx.collections.*;
  import javafx.fxml.FXML;
  import javafx.fxml.Initializable;
  import javafx.scene.control.*;
  import javafx.scene.control.cell.PropertyValueFactory;
  import java.net.URL;
  import java.sql.SQLException;
  import java.util.List;
  import java.util.ResourceBundle;
  public class BrowseVehiclesController implements Initializable {
      @FXML private TextField searchField;
      @FXML private TableView<Vehicle> table;
      @FXML private TableColumn<Vehicle,Integer> colId,colYear;
      @FXML private TableColumn<Vehicle,String>  colReg,colMake,colModel,colOwner;
      private final VehicleDAO dao=new VehicleDAO();
      private final ObservableList<Vehicle> data=FXCollections.observableArrayList();
      @Override public void initialize(URL url, ResourceBundle rb) {
          colId.setCellValueFactory(new PropertyValueFactory<>("vehicleId"));
          colReg.setCellValueFactory(new PropertyValueFactory<>("registrationNumber"));
          colMake.setCellValueFactory(new PropertyValueFactory<>("make"));
          colModel.setCellValueFactory(new PropertyValueFactory<>("model"));
          colYear.setCellValueFactory(new PropertyValueFactory<>("year"));
          colOwner.setCellValueFactory(new PropertyValueFactory<>("ownerName"));
          try{data.setAll(dao.findAll());}catch(SQLException e){AlertUtil.error("DB Error",e.getMessage());}
          table.setItems(data);
      }
      public List<Vehicle> findAll() throws SQLException { return dao.findAll(); }
      @FXML public void handleSearch() {
          String val=searchField.getText();
          if(val==null||val.isBlank()){table.setItems(data);return;}
          String l=val.toLowerCase();
          table.setItems(data.filtered(v->v.getRegistrationNumber().toLowerCase().contains(l)||
              v.getMake().toLowerCase().contains(l)||v.getModel().toLowerCase().contains(l)||
              (v.getOwnerName()!=null&&v.getOwnerName().toLowerCase().contains(l))));
      }
  }