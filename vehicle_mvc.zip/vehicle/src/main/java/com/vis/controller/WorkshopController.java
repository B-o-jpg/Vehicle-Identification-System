package com.vis.controller;
  import com.vis.dao.ServiceRecordDAO;
  import com.vis.dao.VehicleDAO;
  import com.vis.model.*;
  import com.vis.util.*;
  import javafx.collections.*;
  import javafx.fxml.FXML;
  import javafx.fxml.Initializable;
  import javafx.geometry.Insets;
  import javafx.scene.control.*;
  import javafx.scene.control.cell.PropertyValueFactory;
  import java.net.URL;
  import java.sql.SQLException;
  import java.time.LocalDate;
  import java.util.*;
  public class WorkshopController implements Initializable {
      @FXML private Label  pageTitle,pageSubtitle;
      @FXML private Button addBtn,editBtn,deleteBtn;
      @FXML private TableView<ServiceRecord> table;
      @FXML private TableColumn<ServiceRecord,Integer> colId;
      @FXML private TableColumn<ServiceRecord,String>  colReg,colDate,colType,colDesc;
      @FXML private TableColumn<ServiceRecord,Double>  colCost;
      private final ServiceRecordDAO dao=new ServiceRecordDAO();
      private final ObservableList<ServiceRecord> data=FXCollections.observableArrayList();
      @Override public void initialize(URL url, ResourceBundle rb) {
          boolean canEdit=SessionManager.isAdmin()||SessionManager.isWorkshop();
          pageTitle.setText(SessionManager.isCustomer()?"My Service Records":"Service Records");
          pageSubtitle.setText(SessionManager.isCustomer()?"Service history for your vehicles":"All workshop service records");
          if(canEdit){addBtn.setVisible(true);addBtn.setManaged(true);editBtn.setVisible(true);editBtn.setManaged(true);deleteBtn.setVisible(true);deleteBtn.setManaged(true);}
          colId.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
          colReg.setCellValueFactory(new PropertyValueFactory<>("registrationNumber"));
          colDate.setCellValueFactory(new PropertyValueFactory<>("serviceDate"));
          colType.setCellValueFactory(new PropertyValueFactory<>("serviceType"));
          colDesc.setCellValueFactory(new PropertyValueFactory<>("description"));
          colCost.setCellValueFactory(new PropertyValueFactory<>("cost"));
          table.setItems(data); refresh();
      }
      public List<ServiceRecord> getAll() throws SQLException { return dao.findAll(); }
      public List<ServiceRecord> getByCustomer(int cid) throws SQLException { return dao.findByCustomer(cid); }
      public void registerService(int vehicleId,LocalDate date,String type,String desc,double cost) throws SQLException {
          if(date==null) throw new IllegalArgumentException("Date is required");
          if(type==null||type.isBlank()) throw new IllegalArgumentException("Service type is required");
          if(cost<0) throw new IllegalArgumentException("Cost cannot be negative");
          dao.registerService(vehicleId,date,type,desc,cost);
      }
      public void update(ServiceRecord sr) throws SQLException {
          if(sr.getServiceType()==null||sr.getServiceType().isBlank()) throw new IllegalArgumentException("Type is required");
          dao.update(sr);
      }
      public void delete(int id) throws SQLException { dao.delete(id); }
      @FXML public void handleAdd() { showForm(null); }
      @FXML public void handleEdit() {
          ServiceRecord sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a record.");return;} showForm(sel);
      }
      @FXML public void handleDelete() {
          ServiceRecord sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a record to delete.");return;}
          if(AlertUtil.confirm("Confirm","Delete service record #"+sel.getServiceId()+"?")){
              try{delete(sel.getServiceId());refresh();AlertUtil.info("Deleted","Record deleted.");}
              catch(SQLException ex){AlertUtil.error("Error",ex.getMessage());}
          }
      }
      private void showForm(ServiceRecord existing) {
          boolean isEdit=existing!=null;
          Dialog<ServiceRecord> dlg=new Dialog<>(); dlg.setTitle(isEdit?"Edit Service Record":"Register Service");
          javafx.scene.layout.GridPane grid=new javafx.scene.layout.GridPane();
          grid.setHgap(10);grid.setVgap(10);grid.setPadding(new Insets(20));
          ComboBox<String> vehBox=vehicleCombo(isEdit?existing.getRegistrationNumber():null);
          Map<String,Integer> regToId=vehicleMap();
          DatePicker dp=new DatePicker(isEdit?existing.getServiceDate():LocalDate.now());
          TextField tf=tf(isEdit?existing.getServiceType():""),df=tf(isEdit?existing.getDescription():""),cf=tf(isEdit?String.format("%.2f",existing.getCost()):"0.00");
          grid.addRow(0,new Label("Vehicle:"),vehBox);grid.addRow(1,new Label("Date:"),dp);
          grid.addRow(2,new Label("Type:"),tf);grid.addRow(3,new Label("Description:"),df);grid.addRow(4,new Label("Cost (R):"),cf);
          dlg.getDialogPane().setContent(grid);
          dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
          dlg.setResultConverter(btn->{
              if(btn!=ButtonType.OK)return null;
              try{ServiceRecord sr=isEdit?existing:new ServiceRecord();
                  String sel=vehBox.getValue();if(sel!=null)sr.setVehicleId(regToId.getOrDefault(sel,0));
                  sr.setServiceDate(dp.getValue());sr.setServiceType(tf.getText().trim());
                  sr.setDescription(df.getText().trim());sr.setCost(Double.parseDouble(cf.getText().trim()));return sr;}
              catch(NumberFormatException e){AlertUtil.error("Input Error","Cost must be a number.");return null;}
          });
          dlg.showAndWait().ifPresent(sr->{
              try{if(isEdit)update(sr);else registerService(sr.getVehicleId(),sr.getServiceDate(),sr.getServiceType(),sr.getDescription(),sr.getCost());
                  refresh();AlertUtil.info("Success",isEdit?"Record updated.":"Service registered.");}
              catch(Exception e){AlertUtil.error("Error",e.getMessage());}
          });
      }
      private void refresh(){
          try{AppUser u=SessionManager.getCurrentUser();
              data.setAll((SessionManager.isCustomer()&&u.getCustomerId()!=null)?getByCustomer(u.getCustomerId()):getAll());}
          catch(SQLException e){AlertUtil.error("DB Error",e.getMessage());}
      }
      private ComboBox<String> vehicleCombo(String sel){
          ComboBox<String> box=new ComboBox<>();
          try{for(Vehicle v:new VehicleDAO().findAll()){String l=v.getRegistrationNumber()+" ("+v.getMake()+" "+v.getModel()+")";box.getItems().add(l);if(sel!=null&&l.startsWith(sel))box.setValue(l);}}catch(SQLException e){}
          if(box.getValue()==null&&!box.getItems().isEmpty())box.setValue(box.getItems().get(0));return box;
      }
      private Map<String,Integer> vehicleMap(){
          Map<String,Integer> m=new LinkedHashMap<>();
          try{for(Vehicle v:new VehicleDAO().findAll())m.put(v.getRegistrationNumber()+" ("+v.getMake()+" "+v.getModel()+")",v.getVehicleId());}catch(SQLException e){}
          return m;
      }
      private TextField tf(String v){TextField f=new TextField(v);f.setStyle(Theme.INPUT_STYLE);f.setPrefWidth(220);return f;}
  }