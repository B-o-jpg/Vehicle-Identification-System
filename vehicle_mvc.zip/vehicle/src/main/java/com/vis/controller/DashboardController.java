package com.vis.controller;

  import com.vis.Main;
  import com.vis.dao.*;
  import com.vis.model.*;
  import com.vis.util.*;
  import javafx.fxml.FXML;
  import javafx.fxml.FXMLLoader;
  import javafx.fxml.Initializable;
  import javafx.geometry.Insets;
  import javafx.geometry.Pos;
  import javafx.scene.Node;
  import javafx.scene.chart.*;
  import javafx.scene.control.*;
  import javafx.scene.layout.*;
  import javafx.scene.paint.Color;
  import javafx.scene.text.*;
  import java.net.URL;
  import java.sql.SQLException;
  import java.util.List;
  import java.util.ResourceBundle;

  public class DashboardController implements Initializable {

      @FXML private BorderPane rootPane;
      @FXML private VBox       sidebarContainer;
      @FXML private Label      sidebarLogo;
      @FXML private Label      sidebarRole;
      @FXML private Label      sidebarName;
      @FXML private VBox       navContainer;
      @FXML private ScrollPane contentScroll;
      @FXML private Label      pageTitle;
      @FXML private Label      pageSubtitle;
      @FXML private HBox       statsRow;
      @FXML private HBox       chartsRow;

      @Override
      public void initialize(URL url, ResourceBundle rb) {
          AppUser user = SessionManager.getCurrentUser();
          buildSidebar(user);
          buildContent(user);
      }

      // ── Sidebar ────────────────────────────────────────────────────────────
      private void buildSidebar(AppUser user) {
          sidebarRole.setText(user.getRole().name());
          sidebarRole.setPadding(new Insets(0, 0, 0, 18));
          sidebarName.setText(user.getFullName());

          String r = user.getRole().name();
          switch (r) {
              case "ADMIN"     -> { addNav("Dashboard","DASHBOARD"); addNav("Customers","CUSTOMERS");
                                    addNav("Vehicles","VEHICLES");   addNav("Service Records","WORKSHOP");
                                    addNav("Police Reports","POLICE"); addNav("Violations","VIOLATIONS");
                                    addNav("Insurance","INSURANCE"); }
              case "CUSTOMER"  -> { addNav("Dashboard","DASHBOARD"); addNav("My Vehicles","VEHICLES");
                                    addNav("My Service Records","WORKSHOP"); addNav("My Police Reports","POLICE");
                                    addNav("My Violations","VIOLATIONS"); }
              case "POLICE"    -> { addNav("Dashboard","DASHBOARD"); addNav("Police Reports","POLICE");
                                    addNav("Violations","VIOLATIONS"); addNav("Browse Vehicles","BROWSE"); }
              case "INSURANCE" -> { addNav("Dashboard","DASHBOARD"); addNav("Insurance Records","INSURANCE");
                                    addNav("Vehicles","VEHICLES"); }
              case "WORKSHOP"  -> { addNav("Dashboard","DASHBOARD"); addNav("Service Records","WORKSHOP");
                                    addNav("Vehicles","VEHICLES"); }
          }
      }

      private void addNav(String label, String action) {
          Button b = new Button(label);
          b.setMaxWidth(Double.MAX_VALUE);
          b.getStyleClass().add("nav-btn");
          b.setOnAction(e -> navigate(action));
          navContainer.getChildren().add(b);
      }

      @FXML
      public void handleLogout() { Main.logout(); }

      private void navigate(String action) {
          if ("DASHBOARD".equals(action)) {
              rootPane.setCenter(contentScroll);
              buildContent(SessionManager.getCurrentUser());
              return;
          }
          try {
              String fxml = switch (action) {
                  case "CUSTOMERS"  -> "/com/vis/view/customer.fxml";
                  case "VEHICLES"   -> "/com/vis/view/vehicle.fxml";
                  case "WORKSHOP"   -> "/com/vis/view/workshop.fxml";
                  case "POLICE"     -> "/com/vis/view/police_reports.fxml";
                  case "VIOLATIONS" -> "/com/vis/view/violations.fxml";
                  case "INSURANCE"  -> "/com/vis/view/insurance.fxml";
                  case "BROWSE"     -> "/com/vis/view/browse_vehicles.fxml";
                  default           -> null;
              };
              if (fxml != null) {
                  Node view = FXMLLoader.load(getClass().getResource(fxml));
                  rootPane.setCenter(view);
              }
          } catch (Exception e) {
              AlertUtil.error("Navigation Error", e.getMessage());
          }
      }

      // ── Dashboard content ─────────────────────────────────────────────────
      private void buildContent(AppUser user) {
          pageTitle.setText("Dashboard");
          pageSubtitle.setText("Welcome, " + user.getFullName() + " — " + user.getRole().name());
          statsRow.getChildren().clear();
          chartsRow.getChildren().clear();
          try {
              if (SessionManager.isAdmin()) {
                  long cust = new CustomerDAO().findAll().size();
                  long veh  = new VehicleDAO().findAll().size();
                  long svc  = new ServiceRecordDAO().findAll().size();
                  long viol = new ViolationDAO().findUnpaid().size();
                  statsRow.getChildren().addAll(
                      statCard("Customers",    String.valueOf(cust), "#4F46E5"),
                      statCard("Vehicles",     String.valueOf(veh),  "#7C3AED"),
                      statCard("Services",     String.valueOf(svc),  "#F59E0B"),
                      statCard("Unpaid Fines", String.valueOf(viol), "#EF4444"));
                  chartsRow.getChildren().addAll(vehiclePieChart(), serviceBarChart());

              } else if (SessionManager.isCustomer()) {
                  int cid = user.getCustomerId() != null ? user.getCustomerId() : 0;
                  long veh  = new VehicleDAO().findByCustomer(cid).size();
                  long svc  = new ServiceRecordDAO().findByCustomer(cid).size();
                  long viol = new ViolationDAO().findByCustomer(cid).size();
                  long rep  = new PoliceReportDAO().findByCustomer(cid).size();
                  statsRow.getChildren().addAll(
                      statCard("My Vehicles",     String.valueOf(veh),  "#4F46E5"),
                      statCard("Service Records", String.valueOf(svc),  "#7C3AED"),
                      statCard("Violations",      String.valueOf(viol), "#EF4444"),
                      statCard("Police Reports",  String.valueOf(rep),  "#F59E0B"));
                  chartsRow.getChildren().addAll(customerServiceChart(cid), customerViolationChart(cid));

              } else if (SessionManager.isPolice()) {
                  long rep  = new PoliceReportDAO().findAll().size();
                  long viol = new ViolationDAO().findAll().size();
                  long unpd = new ViolationDAO().findUnpaid().size();
                  statsRow.getChildren().addAll(
                      statCard("Total Reports",    String.valueOf(rep),  "#4F46E5"),
                      statCard("Total Violations", String.valueOf(viol), "#7C3AED"),
                      statCard("Unpaid Fines",     String.valueOf(unpd), "#EF4444"));
                  chartsRow.getChildren().addAll(violationBarChart(), reportTypeChart());

              } else if (SessionManager.isInsurance()) {
                  long veh  = new VehicleDAO().findAll().size();
                  long paid = new ViolationDAO().findAll().stream()
                      .filter(v -> "Paid".equals(v.getStatus())).count();
                  long unpd = new ViolationDAO().findUnpaid().size();
                  statsRow.getChildren().addAll(
                      statCard("Insured Vehicles",  String.valueOf(veh),  "#4F46E5"),
                      statCard("Paid Fines",        String.valueOf(paid), "#7C3AED"),
                      statCard("Outstanding Fines", String.valueOf(unpd), "#EF4444"));
                  chartsRow.getChildren().addAll(vehiclePieChart(), insuranceViolationPie());

              } else if (SessionManager.isWorkshop()) {
                  long svc = new ServiceRecordDAO().findAll().size();
                  long veh = new VehicleDAO().findAll().size();
                  double rev = new ServiceRecordDAO().findAll().stream()
                      .mapToDouble(ServiceRecord::getCost).sum();
                  statsRow.getChildren().addAll(
                      statCard("Service Records", String.valueOf(svc),         "#4F46E5"),
                      statCard("Vehicles Served", String.valueOf(veh),         "#7C3AED"),
                      statCard("Total Revenue",   String.format("R%.0f", rev), "#F59E0B"));
                  chartsRow.getChildren().addAll(serviceBarChart(), serviceTypePieChart());
              }
          } catch (SQLException ex) {
              statsRow.getChildren().add(new Label("Could not load stats: " + ex.getMessage()));
          }
      }

      private Node statCard(String label, String value, String colorHex) {
          VBox card = new VBox(6);
          card.setAlignment(Pos.CENTER);
          card.setPadding(new Insets(24, 32, 24, 32));
          card.setStyle("-fx-background-color:" + colorHex +
              ";-fx-background-radius:14;-fx-effect:dropshadow(gaussian,rgba(0,0,0,0.2),16,0,0,5);");
          Label val = new Label(value);
          val.setFont(Font.font(Theme.FONT_FAMILY, FontWeight.BLACK, 36));
          val.setTextFill(Color.WHITE);
          Label lbl = new Label(label);
          lbl.setFont(Font.font(Theme.FONT_FAMILY, FontWeight.BOLD, 13));
          lbl.setTextFill(Color.web("rgba(255,255,255,0.85)"));
          card.getChildren().addAll(val, lbl);
          return card;
      }

      private Node vehiclePieChart() {
          try {
              List<Vehicle> vehicles = new VehicleDAO().findAll();
              java.util.Map<String,Long> byMake = new java.util.TreeMap<>();
              for (Vehicle v : vehicles) byMake.merge(v.getMake(), 1L, Long::sum);
              PieChart pie = new PieChart();
              byMake.forEach((make, cnt) -> pie.getData().add(new PieChart.Data(make, cnt)));
              pie.setTitle("Vehicles by Make"); pie.setPrefSize(360, 240);
              return pie;
          } catch (SQLException e) { return new Label("Chart unavailable"); }
      }

      private Node serviceBarChart() {
          try {
              List<ServiceRecord> recs = new ServiceRecordDAO().findAll();
              java.util.Map<String,Long> byType = new java.util.TreeMap<>();
              for (ServiceRecord s : recs) byType.merge(s.getServiceType(), 1L, Long::sum);
              CategoryAxis xAxis = new CategoryAxis(); NumberAxis yAxis = new NumberAxis();
              BarChart<String,Number> bar = new BarChart<>(xAxis, yAxis);
              bar.setTitle("Services by Type");
              XYChart.Series<String,Number> series = new XYChart.Series<>();
              series.setName("Count");
              byType.forEach((t, c) -> series.getData().add(new XYChart.Data<>(t, c)));
              bar.getData().add(series); bar.setPrefSize(420, 240); bar.setLegendVisible(false);
              return bar;
          } catch (SQLException e) { return new Label("Chart unavailable"); }
      }

      private Node customerServiceChart(int cid) {
          try {
              List<ServiceRecord> recs = new ServiceRecordDAO().findByCustomer(cid);
              java.util.Map<String,Long> byType = new java.util.TreeMap<>();
              for (ServiceRecord s : recs) byType.merge(s.getServiceType(), 1L, Long::sum);
              PieChart pie = new PieChart();
              byType.forEach((t, c) -> pie.getData().add(new PieChart.Data(t, c)));
              pie.setTitle("My Services by Type"); pie.setPrefSize(360, 240);
              return pie;
          } catch (SQLException e) { return new Label("Chart unavailable"); }
      }

      private Node customerViolationChart(int cid) {
          try {
              List<Violation> vList = new ViolationDAO().findByCustomer(cid);
              long paid   = vList.stream().filter(v -> "Paid".equals(v.getStatus())).count();
              long unpaid = vList.size() - paid;
              PieChart pie = new PieChart();
              if (paid > 0)   pie.getData().add(new PieChart.Data("Paid",   paid));
              if (unpaid > 0) pie.getData().add(new PieChart.Data("Unpaid", unpaid));
              pie.setTitle("My Violations"); pie.setPrefSize(360, 240);
              return pie;
          } catch (SQLException e) { return new Label("Chart unavailable"); }
      }

      private Node violationBarChart() {
          try {
              List<Violation> vList = new ViolationDAO().findAll();
              java.util.Map<String,Long> byType = new java.util.TreeMap<>();
              for (Violation v : vList) byType.merge(v.getViolationType(), 1L, Long::sum);
              CategoryAxis xAxis = new CategoryAxis(); NumberAxis yAxis = new NumberAxis();
              BarChart<String,Number> bar = new BarChart<>(xAxis, yAxis);
              bar.setTitle("Violations by Type");
              XYChart.Series<String,Number> series = new XYChart.Series<>();
              series.setName("Count");
              byType.forEach((t, c) -> series.getData().add(new XYChart.Data<>(t, c)));
              bar.getData().add(series); bar.setPrefSize(420, 240); bar.setLegendVisible(false);
              return bar;
          } catch (SQLException e) { return new Label("Chart unavailable"); }
      }

      private Node reportTypeChart() {
          try {
              List<PoliceReport> reps = new PoliceReportDAO().findAll();
              java.util.Map<String,Long> byType = new java.util.TreeMap<>();
              for (PoliceReport r : reps) byType.merge(r.getReportType(), 1L, Long::sum);
              PieChart pie = new PieChart();
              byType.forEach((t, c) -> pie.getData().add(new PieChart.Data(t, c)));
              pie.setTitle("Reports by Type"); pie.setPrefSize(360, 240);
              return pie;
          } catch (SQLException e) { return new Label("Chart unavailable"); }
      }

      private Node insuranceViolationPie() {
          try {
              List<Violation> vList = new ViolationDAO().findAll();
              long paid   = vList.stream().filter(v -> "Paid".equals(v.getStatus())).count();
              long unpaid = vList.size() - paid;
              PieChart pie = new PieChart();
              if (paid > 0)   pie.getData().add(new PieChart.Data("Paid",   paid));
              if (unpaid > 0) pie.getData().add(new PieChart.Data("Unpaid", unpaid));
              pie.setTitle("Violation Payment Status"); pie.setPrefSize(360, 240);
              return pie;
          } catch (SQLException e) { return new Label("Chart unavailable"); }
      }

      private Node serviceTypePieChart() {
          try {
              List<ServiceRecord> recs = new ServiceRecordDAO().findAll();
              java.util.Map<String,Long> byType = new java.util.TreeMap<>();
              for (ServiceRecord s : recs) byType.merge(s.getServiceType(), 1L, Long::sum);
              PieChart pie = new PieChart();
              byType.forEach((t, c) -> pie.getData().add(new PieChart.Data(t, c)));
              pie.setTitle("Service Types"); pie.setPrefSize(360, 240);
              return pie;
          } catch (SQLException e) { return new Label("Chart unavailable"); }
      }
  }
  