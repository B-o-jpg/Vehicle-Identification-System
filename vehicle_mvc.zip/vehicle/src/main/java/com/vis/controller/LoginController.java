package com.vis.controller;
  import com.vis.Main;
  import com.vis.dao.AppUserDAO;
  import com.vis.model.AppUser;
  import com.vis.util.SessionManager;
  import javafx.fxml.FXML;
  import javafx.fxml.Initializable;
  import javafx.scene.control.*;
  import java.net.URL;
  import java.sql.SQLException;
  import java.util.Optional;
  import java.util.ResourceBundle;
  public class LoginController implements Initializable {
      @FXML private TextField     userIdField;
      @FXML private PasswordField passwordField;
      @FXML private Label         errorLabel;
      private final AppUserDAO userDAO = new AppUserDAO();
      @Override public void initialize(URL url, ResourceBundle rb) {}
      public Optional<AppUser> login(String userId, String password) throws SQLException {
          if (userId==null||userId.isBlank()||password==null||password.isBlank())
              throw new IllegalArgumentException("User ID and password are required");
          Optional<AppUser> user = userDAO.authenticate(userId.trim(), password);
          user.ifPresent(SessionManager::setCurrentUser);
          return user;
      }
      public void register(String userId, String password, String role, String fullName,
                           String address, String phone, String email) throws SQLException {
          if (userId==null||userId.isBlank()) throw new IllegalArgumentException("User ID is required");
          if (password==null||password.length()<6) throw new IllegalArgumentException("Password must be at least 6 characters");
          userDAO.register(userId.trim(), password, role, fullName, address, phone, email);
      }
      @FXML public void handleLogin() {
          errorLabel.setText("");
          try {
              Optional<AppUser> user = login(userIdField.getText().trim(), passwordField.getText());
              if (user.isPresent()) Main.showDashboard();
              else errorLabel.setText("Invalid credentials. Please try again.");
          } catch (IllegalArgumentException ex) { errorLabel.setText(ex.getMessage());
          } catch (SQLException ex) { errorLabel.setText("Database error: " + ex.getMessage()); }
      }
      @FXML public void handleRegister() { Main.showRegister(); }
  }