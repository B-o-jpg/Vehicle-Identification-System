package com.vis.controller;
  import com.vis.dao.CustomerDAO;
  import com.vis.dao.VehicleDAO;
  import com.vis.model.*;
  import com.vis.util.*;
  import javafx.collections.*;
  import javafx.fxml.FXML;
  import javafx.fxml.Initializable;
  import javafx.geometry.Insets;
  import javafx.scene.control.*;
  import javafx.scene.control.cell.PropertyValueFactory;
  import java.net.URL;
  import java.sql.SQLException;
  import java.util.*;
  public class InsuranceController implements Initializable {
      @FXML private Button addBtn,editBtn,deleteBtn;
      @FXML private TableView<Vehicle> table;
      @FXML private TableColumn<Vehicle,Integer> colId,colYear;
      @FXML private TableColumn<Vehicle,String>  colReg,colMake,colModel,colOwner;
      private final VehicleDAO dao=new VehicleDAO();
      private final ObservableList<Vehicle> data=FXCollections.observableArrayList();
      @Override public void initialize(URL url, ResourceBundle rb) {
          boolean canEdit=SessionManager.isAdmin()||SessionManager.isInsurance();
          if(canEdit){addBtn.setVisible(true);addBtn.setManaged(true);editBtn.setVisible(true);editBtn.setManaged(true);deleteBtn.setVisible(true);deleteBtn.setManaged(true);}
          colId.setCellValueFactory(new PropertyValueFactory<>("vehicleId"));
          colReg.setCellValueFactory(new PropertyValueFactory<>("registrationNumber"));
          colMake.setCellValueFactory(new PropertyValueFactory<>("make"));
          colModel.setCellValueFactory(new PropertyValueFactory<>("model"));
          colYear.setCellValueFactory(new PropertyValueFactory<>("year"));
          colOwner.setCellValueFactory(new PropertyValueFactory<>("ownerName"));
          table.setItems(data); refresh();
      }
      public List<Vehicle> getInsuredVehicles() throws SQLException { return dao.findAll(); }
      public List<Vehicle> getByCustomer(int cid) throws SQLException { return dao.findByCustomer(cid); }
      public void registerForInsurance(String reg,String make,String model,int year,Integer ownerId) throws SQLException { dao.addVehicle(reg.trim().toUpperCase(),make,model,year,ownerId); }
      public void update(Vehicle v) throws SQLException { dao.update(v); }
      public void delete(int id) throws SQLException { dao.delete(id); }
      @FXML public void handleAdd() { showForm(null); }
      @FXML public void handleEdit() {
          Vehicle sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a vehicle.");return;} showForm(sel);
      }
      @FXML public void handleDelete() {
          Vehicle sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a vehicle.");return;}
          if(AlertUtil.confirm("Confirm","Remove vehicle "+sel.getRegistrationNumber()+" from insurance?")){
              try{delete(sel.getVehicleId());refresh();AlertUtil.info("Removed","Vehicle removed.");}
              catch(SQLException ex){AlertUtil.error("Error",ex.getMessage());}
          }
      }
      private void showForm(Vehicle existing) {
          boolean isEdit=existing!=null;
          Dialog<Vehicle> dlg=new Dialog<>(); dlg.setTitle(isEdit?"Edit Insurance Record":"Register Vehicle for Insurance");
          javafx.scene.layout.GridPane grid=new javafx.scene.layout.GridPane();
          grid.setHgap(10);grid.setVgap(10);grid.setPadding(new Insets(20));
          TextField rf=tf(isEdit?existing.getRegistrationNumber():""),mf=tf(isEdit?existing.getMake():""),modf=tf(isEdit?existing.getModel():""),yf=tf(isEdit?String.valueOf(existing.getYear()):"");
          ComboBox<String> ownerBox=new ComboBox<>();Map<String,Integer> nameToId=new LinkedHashMap<>();
          nameToId.put("(None)",null);ownerBox.getItems().add("(None)");
          try{for(Customer c:new CustomerDAO().findAll()){String l=c.getName()+" ["+c.getId()+"]";ownerBox.getItems().add(l);nameToId.put(l,c.getId());if(isEdit&&c.getId()==existing.getOwnerId())ownerBox.setValue(l);}}catch(SQLException e){}
          if(ownerBox.getValue()==null)ownerBox.setValue("(None)");
          grid.addRow(0,new Label("Registration:"),rf);grid.addRow(1,new Label("Make:"),mf);
          grid.addRow(2,new Label("Model:"),modf);grid.addRow(3,new Label("Year:"),yf);grid.addRow(4,new Label("Owner:"),ownerBox);
          dlg.getDialogPane().setContent(grid);
          dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
          dlg.setResultConverter(btn->{
              if(btn!=ButtonType.OK)return null;
              try{Vehicle v=isEdit?existing:new Vehicle();v.setRegistrationNumber(rf.getText().trim().toUpperCase());
                  v.setMake(mf.getText().trim());v.setModel(modf.getText().trim());v.setYear(Integer.parseInt(yf.getText().trim()));
                  Integer oid=nameToId.get(ownerBox.getValue());v.setOwnerId(oid!=null?oid:0);return v;}
              catch(NumberFormatException e){AlertUtil.error("Input Error","Year must be a number.");return null;}
          });
          dlg.showAndWait().ifPresent(v->{
              try{if(isEdit)update(v);else registerForInsurance(v.getRegistrationNumber(),v.getMake(),v.getModel(),v.getYear(),v.getOwnerId()!=0?v.getOwnerId():null);
                  refresh();AlertUtil.info("Success",isEdit?"Record updated.":"Vehicle registered for insurance.");}
              catch(Exception e){AlertUtil.error("Error",e.getMessage());}
          });
      }
      private void refresh(){try{data.setAll(getInsuredVehicles());}catch(SQLException e){AlertUtil.error("DB Error",e.getMessage());}}
      private TextField tf(String v){TextField f=new TextField(v);f.setStyle(Theme.INPUT_STYLE);f.setPrefWidth(220);return f;}
  }