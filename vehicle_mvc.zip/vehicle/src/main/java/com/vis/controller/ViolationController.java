package com.vis.controller;
  import com.vis.dao.VehicleDAO;
  import com.vis.dao.ViolationDAO;
  import com.vis.model.*;
  import com.vis.util.*;
  import javafx.collections.*;
  import javafx.fxml.FXML;
  import javafx.fxml.Initializable;
  import javafx.geometry.Insets;
  import javafx.scene.control.*;
  import javafx.scene.control.cell.PropertyValueFactory;
  import java.net.URL;
  import java.sql.SQLException;
  import java.time.LocalDate;
  import java.util.*;
  public class ViolationController implements Initializable {
      @FXML private Label  pageTitle,pageSubtitle;
      @FXML private Button addBtn,editBtn,deleteBtn,payBtn;
      @FXML private TableView<Violation> table;
      @FXML private TableColumn<Violation,Integer> colId,colVehicle;
      @FXML private TableColumn<Violation,String>  colReg,colDate,colType,colStatus;
      @FXML private TableColumn<Violation,Double>  colFine;
      private final ViolationDAO dao=new ViolationDAO();
      private final ObservableList<Violation> data=FXCollections.observableArrayList();
      @Override public void initialize(URL url, ResourceBundle rb) {
          boolean canEdit=SessionManager.isAdmin()||SessionManager.isPolice(),isCust=SessionManager.isCustomer();
          pageTitle.setText(isCust?"My Violations":"Traffic Violations");
          pageSubtitle.setText("Traffic fines and violation records");
          if(canEdit){addBtn.setVisible(true);addBtn.setManaged(true);editBtn.setVisible(true);editBtn.setManaged(true);deleteBtn.setVisible(true);deleteBtn.setManaged(true);payBtn.setVisible(true);payBtn.setManaged(true);}
          else if(isCust){payBtn.setText("Pay Selected Fine");payBtn.setVisible(true);payBtn.setManaged(true);}
          colId.setCellValueFactory(new PropertyValueFactory<>("violationId"));
          colVehicle.setCellValueFactory(new PropertyValueFactory<>("vehicleId"));
          colReg.setCellValueFactory(new PropertyValueFactory<>("registrationNumber"));
          colDate.setCellValueFactory(new PropertyValueFactory<>("violationDate"));
          colType.setCellValueFactory(new PropertyValueFactory<>("violationType"));
          colFine.setCellValueFactory(new PropertyValueFactory<>("fineAmount"));
          colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
          colStatus.setCellFactory(col->new TableCell<>(){
              @Override protected void updateItem(String item,boolean empty){
                  super.updateItem(item,empty);
                  if(empty||item==null){setText(null);setStyle("");return;}
                  setText(item);setStyle("Paid".equals(item)?"-fx-text-fill:#059669;-fx-font-weight:bold;":"-fx-text-fill:#DC2626;-fx-font-weight:bold;");
              }
          });
          table.setItems(data); refresh();
      }
      public List<Violation> getViolations() throws SQLException { return dao.findAll(); }
      public List<Violation> getViolationsByCustomer(int cid) throws SQLException { return dao.findByCustomer(cid); }
      public List<Violation> getUnpaid() throws SQLException { return dao.findUnpaid(); }
      public void issueViolation(int vehicleId,LocalDate date,String type,double fine,String status) throws SQLException { dao.create(vehicleId,date,type,fine,status); }
      public void updateViolation(Violation v) throws SQLException { dao.update(v); }
      public void deleteViolation(int id) throws SQLException { dao.delete(id); }
      public void payViolation(int id) throws SQLException { dao.payViolation(id); }
      @FXML public void handleAdd() { showForm(null); }
      @FXML public void handleEdit() {
          Violation sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a violation.");return;} showForm(sel);
      }
      @FXML public void handleDelete() {
          Violation sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a violation to delete.");return;}
          if(AlertUtil.confirm("Confirm","Delete violation #"+sel.getViolationId()+"?")){
              try{deleteViolation(sel.getViolationId());refresh();AlertUtil.info("Deleted","Violation deleted.");}
              catch(SQLException ex){AlertUtil.error("Error",ex.getMessage());}
          }
      }
      @FXML public void handlePay() {
          Violation sel=table.getSelectionModel().getSelectedItem();
          if(sel==null){AlertUtil.warn("No Selection","Select a violation.");return;}
          try{payViolation(sel.getViolationId());refresh();AlertUtil.info("Paid","Violation marked as paid.");}
          catch(SQLException ex){AlertUtil.error("Error",ex.getMessage());}
      }
      private void showForm(Violation existing) {
          boolean isEdit=existing!=null;
          Dialog<Violation> dlg=new Dialog<>(); dlg.setTitle(isEdit?"Edit Violation":"Issue Violation");
          javafx.scene.layout.GridPane grid=new javafx.scene.layout.GridPane();
          grid.setHgap(10);grid.setVgap(10);grid.setPadding(new Insets(20));
          ComboBox<String> vehBox=vehicleCombo(isEdit?existing.getRegistrationNumber():null);
          Map<String,Integer> regToId=vehicleMap();
          DatePicker dp=new DatePicker(isEdit?existing.getViolationDate():LocalDate.now());
          TextField tf=tf(isEdit?existing.getViolationType():""),ff=tf(isEdit?String.format("%.2f",existing.getFineAmount()):"0.00");
          ComboBox<String> statusBox=new ComboBox<>();statusBox.getItems().addAll("Unpaid","Paid");statusBox.setValue(isEdit?existing.getStatus():"Unpaid");
          grid.addRow(0,new Label("Vehicle:"),vehBox);grid.addRow(1,new Label("Date:"),dp);
          grid.addRow(2,new Label("Type:"),tf);grid.addRow(3,new Label("Fine (R):"),ff);grid.addRow(4,new Label("Status:"),statusBox);
          dlg.getDialogPane().setContent(grid);
          dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
          dlg.setResultConverter(btn->{
              if(btn!=ButtonType.OK)return null;
              try{Violation v=isEdit?existing:new Violation();
                  String sel=vehBox.getValue();if(sel!=null)v.setVehicleId(regToId.getOrDefault(sel,0));
                  v.setViolationDate(dp.getValue());v.setViolationType(tf.getText().trim());
                  v.setFineAmount(Double.parseDouble(ff.getText().trim()));v.setStatus(statusBox.getValue());return v;}
              catch(NumberFormatException e){AlertUtil.error("Input Error","Fine must be a number.");return null;}
          });
          dlg.showAndWait().ifPresent(v->{
              try{if(isEdit)updateViolation(v);else issueViolation(v.getVehicleId(),v.getViolationDate(),v.getViolationType(),v.getFineAmount(),v.getStatus());
                  refresh();AlertUtil.info("Success",isEdit?"Violation updated.":"Violation issued.");}
              catch(Exception e){AlertUtil.error("Error",e.getMessage());}
          });
      }
      private void refresh(){
          try{AppUser u=SessionManager.getCurrentUser();
              data.setAll((SessionManager.isCustomer()&&u.getCustomerId()!=null)?getViolationsByCustomer(u.getCustomerId()):getViolations());}
          catch(SQLException e){AlertUtil.error("DB Error",e.getMessage());}
      }
      private ComboBox<String> vehicleCombo(String sel){
          ComboBox<String> box=new ComboBox<>();
          try{for(Vehicle v:new VehicleDAO().findAll()){String l=v.getRegistrationNumber()+" ("+v.getMake()+" "+v.getModel()+")";box.getItems().add(l);if(sel!=null&&l.startsWith(sel))box.setValue(l);}}catch(SQLException e){}
          if(box.getValue()==null&&!box.getItems().isEmpty())box.setValue(box.getItems().get(0));return box;
      }
      private Map<String,Integer> vehicleMap(){
          Map<String,Integer> m=new LinkedHashMap<>();
          try{for(Vehicle v:new VehicleDAO().findAll())m.put(v.getRegistrationNumber()+" ("+v.getMake()+" "+v.getModel()+")",v.getVehicleId());}catch(SQLException e){}
          return m;
      }
      private TextField tf(String v){TextField f=new TextField(v);f.setStyle(Theme.INPUT_STYLE);f.setPrefWidth(220);return f;}
  }