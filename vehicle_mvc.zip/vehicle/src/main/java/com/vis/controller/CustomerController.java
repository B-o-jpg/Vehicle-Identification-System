package com.vis.controller;
  import com.vis.dao.CustomerDAO;
  import com.vis.model.Customer;
  import com.vis.util.AlertUtil;
  import com.vis.util.Theme;
  import javafx.collections.*;
  import javafx.fxml.FXML;
  import javafx.fxml.Initializable;
  import javafx.geometry.Insets;
  import javafx.scene.control.*;
  import javafx.scene.control.cell.PropertyValueFactory;
  import java.net.URL;
  import java.sql.SQLException;
  import java.util.List;
  import java.util.ResourceBundle;
  public class CustomerController implements Initializable {
      @FXML private TableView<Customer>           table;
      @FXML private TableColumn<Customer,Integer> colId;
      @FXML private TableColumn<Customer,String>  colName;
      @FXML private TableColumn<Customer,String>  colAddress;
      @FXML private TableColumn<Customer,String>  colPhone;
      @FXML private TableColumn<Customer,String>  colEmail;
      private final CustomerDAO dao = new CustomerDAO();
      private final ObservableList<Customer> data = FXCollections.observableArrayList();
      @Override public void initialize(URL url, ResourceBundle rb) {
          colId.setCellValueFactory(new PropertyValueFactory<>("id"));
          colName.setCellValueFactory(new PropertyValueFactory<>("name"));
          colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
          colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
          colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
          table.setItems(data); refresh();
      }
      public List<Customer> getAll() throws SQLException { return dao.findAll(); }
      public void create(Customer c) throws SQLException {
          if (c.getName()==null||c.getName().isBlank()) throw new IllegalArgumentException("Name is required");
          dao.create(c);
      }
      public void update(Customer c) throws SQLException {
          if (c.getName()==null||c.getName().isBlank()) throw new IllegalArgumentException("Name is required");
          dao.update(c);
      }
      public void delete(int id) throws SQLException { dao.delete(id); }
      @FXML public void handleAdd() { showForm(null); }
      @FXML public void handleEdit() {
          Customer sel=table.getSelectionModel().getSelectedItem();
          if (sel==null){AlertUtil.warn("No Selection","Select a customer first.");return;} showForm(sel);
      }
      @FXML public void handleDelete() {
          Customer sel=table.getSelectionModel().getSelectedItem();
          if (sel==null){AlertUtil.warn("No Selection","Select a customer to delete.");return;}
          if (AlertUtil.confirm("Confirm Delete","Delete customer '"+sel.getName()+"'?")) {
              try{delete(sel.getId());refresh();AlertUtil.info("Deleted","Customer deleted.");}
              catch(SQLException ex){AlertUtil.error("Error",ex.getMessage());}
          }
      }
      private void showForm(Customer existing) {
          boolean isEdit=existing!=null;
          Dialog<Customer> dlg=new Dialog<>();
          dlg.setTitle(isEdit?"Edit Customer":"Add Customer");
          dlg.setHeaderText(isEdit?"Update customer details":"Enter new customer details");
          javafx.scene.layout.GridPane grid=new javafx.scene.layout.GridPane();
          grid.setHgap(10);grid.setVgap(10);grid.setPadding(new Insets(20));
          TextField nf=tf(isEdit?existing.getName():""),af=tf(isEdit?existing.getAddress():""),
                    pf=tf(isEdit?existing.getPhone():""),ef=tf(isEdit?existing.getEmail():"");
          grid.addRow(0,new Label("Name:"),nf);grid.addRow(1,new Label("Address:"),af);
          grid.addRow(2,new Label("Phone:"),pf);grid.addRow(3,new Label("Email:"),ef);
          dlg.getDialogPane().setContent(grid);
          dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
          dlg.setResultConverter(btn->{
              if(btn!=ButtonType.OK)return null;
              Customer c=isEdit?existing:new Customer();
              c.setName(nf.getText().trim());c.setAddress(af.getText().trim());
              c.setPhone(pf.getText().trim());c.setEmail(ef.getText().trim());
              return c;
          });
          dlg.showAndWait().ifPresent(c->{
              try{if(isEdit)update(c);else create(c);refresh();AlertUtil.info("Success",isEdit?"Customer updated.":"Customer added.");}
              catch(Exception ex){AlertUtil.error("Error",ex.getMessage());}
          });
      }
      private void refresh(){try{data.setAll(getAll());}catch(SQLException e){AlertUtil.error("DB Error",e.getMessage());}}
      private TextField tf(String v){TextField f=new TextField(v);f.setStyle(Theme.INPUT_STYLE);f.setPrefWidth(220);return f;}
  }