package com.vis.controller;
  import com.vis.Main;
  import com.vis.dao.AppUserDAO;
  import com.vis.util.AlertUtil;
  import javafx.fxml.FXML;
  import javafx.fxml.Initializable;
  import javafx.scene.control.*;
  import java.net.URL;
  import java.sql.SQLException;
  import java.util.ResourceBundle;
  public class RegisterController implements Initializable {
      @FXML private TextField        userIdField;
      @FXML private PasswordField    passwordField;
      @FXML private PasswordField    confirmField;
      @FXML private TextField        fullNameField;
      @FXML private TextField        emailField;
      @FXML private TextField        phoneField;
      @FXML private TextField        addressField;
      @FXML private ComboBox<String> roleBox;
      @FXML private Label            errorLabel;
      private final AppUserDAO userDAO = new AppUserDAO();
      @Override public void initialize(URL url, ResourceBundle rb) {
          roleBox.getItems().addAll("CUSTOMER","POLICE","INSURANCE","WORKSHOP");
          roleBox.setValue("CUSTOMER");
      }
      public void register(String uid, String pass, String role, String name,
                           String addr, String phone, String email) throws SQLException {
          if (uid==null||uid.isBlank()) throw new IllegalArgumentException("User ID is required");
          if (pass==null||pass.length()<6) throw new IllegalArgumentException("Password must be at least 6 characters");
          userDAO.register(uid.trim(), pass, role, name, addr, phone, email);
      }
      @FXML public void handleRegister() {
          errorLabel.setText("");
          String uid=userIdField.getText().trim(), pass=passwordField.getText(), conf=confirmField.getText();
          String name=fullNameField.getText().trim(), email=emailField.getText().trim();
          String phone=phoneField.getText().trim(), addr=addressField.getText().trim(), role=roleBox.getValue();
          if (uid.isBlank()||pass.isBlank()||name.isBlank()) { errorLabel.setText("User ID, password, and full name are required."); return; }
          if (!pass.equals(conf)) { errorLabel.setText("Passwords do not match."); return; }
          if (pass.length()<6)    { errorLabel.setText("Password must be at least 6 characters."); return; }
          try {
              register(uid,pass,role,name,addr,phone,email);
              AlertUtil.info("Registration Successful","Account '"+uid+"' created as "+role+".\nYou can now log in.");
              Main.showLogin();
          } catch (IllegalArgumentException ex) { errorLabel.setText(ex.getMessage());
          } catch (Exception ex) { errorLabel.setText("Registration failed: " + ex.getMessage()); }
      }
      @FXML public void handleBack() { Main.showLogin(); }
  }