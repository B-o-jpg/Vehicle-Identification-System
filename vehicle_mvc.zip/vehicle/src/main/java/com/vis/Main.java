package com.vis;
  import com.vis.util.SessionManager;
  import javafx.application.Application;
  import javafx.fxml.FXMLLoader;
  import javafx.scene.Parent;
  import javafx.scene.Scene;
  import javafx.stage.Stage;
  import java.io.IOException;
  public class Main extends Application {
      private static Stage primaryStage;
      @Override public void start(Stage stage) {
          primaryStage = stage;
          stage.setTitle("Vehicle Identification System");
          stage.setMinWidth(1100); stage.setMinHeight(720);
          showLogin(); stage.show();
      }
      public static Stage getPrimaryStage() { return primaryStage; }
      public static void showLogin() {
          try { primaryStage.setScene(new Scene(FXMLLoader.load(Main.class.getResource("/com/vis/view/login.fxml")),1100,720)); }
          catch (IOException e) { e.printStackTrace(); }
      }
      public static void showRegister() {
          try { primaryStage.setScene(new Scene(FXMLLoader.load(Main.class.getResource("/com/vis/view/register.fxml")),1100,720)); }
          catch (IOException e) { e.printStackTrace(); }
      }
      public static void showDashboard() {
          try { primaryStage.setScene(new Scene(FXMLLoader.load(Main.class.getResource("/com/vis/view/dashboard.fxml")),1280,800)); primaryStage.setMaximized(true); }
          catch (IOException e) { e.printStackTrace(); }
      }
      public static void logout() { SessionManager.clear(); showLogin(); }
      public static void main(String[] args) { launch(args); }
  }