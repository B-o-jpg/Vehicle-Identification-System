package com.vis.model;

  import javafx.beans.property.SimpleIntegerProperty;
  import javafx.beans.property.SimpleStringProperty;

  public class Vehicle {
      private int vehicleId;
      private String registrationNumber;
      private String make;
      private String model;
      private int year;
      private int ownerId;
      private String ownerName;

      public Vehicle() {}
      public Vehicle(int vehicleId, String registrationNumber, String make,
                     String model, int year, int ownerId, String ownerName) {
          this.vehicleId = vehicleId; this.registrationNumber = registrationNumber;
          this.make = make; this.model = model; this.year = year;
          this.ownerId = ownerId; this.ownerName = ownerName;
      }
      public int getVehicleId()                    { return vehicleId; }
      public void setVehicleId(int v)              { this.vehicleId = v; }
      public String getRegistrationNumber()        { return registrationNumber; }
      public void setRegistrationNumber(String r)  { this.registrationNumber = r; }
      public String getMake()                      { return make; }
      public void setMake(String m)                { this.make = m; }
      public String getModel()                     { return model; }
      public void setModel(String m)               { this.model = m; }
      public int getYear()                         { return year; }
      public void setYear(int y)                   { this.year = y; }
      public int getOwnerId()                      { return ownerId; }
      public void setOwnerId(int o)                { this.ownerId = o; }
      public String getOwnerName()                 { return ownerName; }
      public void setOwnerName(String n)           { this.ownerName = n; }

      public SimpleIntegerProperty vehicleIdProperty()           { return new SimpleIntegerProperty(vehicleId); }
      public SimpleStringProperty registrationNumberProperty()   { return new SimpleStringProperty(registrationNumber); }
      public SimpleStringProperty makeProperty()                 { return new SimpleStringProperty(make); }
      public SimpleStringProperty modelProperty()                { return new SimpleStringProperty(model); }
      public SimpleIntegerProperty yearProperty()                { return new SimpleIntegerProperty(year); }
      public SimpleStringProperty ownerNameProperty()            { return new SimpleStringProperty(ownerName); }
  }
  