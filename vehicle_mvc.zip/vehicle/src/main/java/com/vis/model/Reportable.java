package com.vis.model;
  public interface Reportable { String getSummary(); String getCategory(); }
  