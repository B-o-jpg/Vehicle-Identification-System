package com.vis.model;

  public class AppUser {
      public enum Role { ADMIN, WORKSHOP, CUSTOMER, POLICE, INSURANCE }

      private String userId;
      private String fullName;
      private Role role;
      private boolean active;
      private Integer customerId; // only set for CUSTOMER role

      public AppUser() {}
      public AppUser(String userId, String fullName, Role role, boolean active) {
          this.userId = userId; this.fullName = fullName; this.role = role; this.active = active;
      }
      public AppUser(String userId, String fullName, Role role, boolean active, Integer customerId) {
          this(userId, fullName, role, active);
          this.customerId = customerId;
      }
      public String getUserId()              { return userId; }
      public void setUserId(String u)        { this.userId = u; }
      public String getFullName()            { return fullName; }
      public void setFullName(String n)      { this.fullName = n; }
      public Role getRole()                  { return role; }
      public void setRole(Role r)            { this.role = r; }
      public boolean isActive()              { return active; }
      public void setActive(boolean a)       { this.active = a; }
      public Integer getCustomerId()         { return customerId; }
      public void setCustomerId(Integer id)  { this.customerId = id; }
  }
  