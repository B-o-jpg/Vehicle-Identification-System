package com.vis;

import com.vis.util.SessionManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        stage.setTitle("Vehicle Identification System");
        stage.setMinWidth(1100);
        stage.setMinHeight(720);
        showLogin();
        stage.show();
    }

    public static Stage getPrimaryStage() { return primaryStage; }

    public static void showLogin() {
        try {
            Parent root = FXMLLoader.load(
                Main.class.getResource("/com/vis/fxml/Login.fxml"));
            primaryStage.setScene(new Scene(root, 1100, 720));
        } catch (Exception e) {
            e.printStackTrace();
            com.vis.util.AlertUtil.error("Screen Error", "Could not load Login screen: " + e.getMessage());
        }
    }

    public static void showRegister() {
        try {
            Parent root = FXMLLoader.load(
                Main.class.getResource("/com/vis/fxml/Register.fxml"));
            primaryStage.setScene(new Scene(root, 1100, 720));
        } catch (Exception e) {
            e.printStackTrace();
            com.vis.util.AlertUtil.error("Screen Error", "Could not load Register screen: " + e.getMessage());
        }
    }

    public static void showDashboard() {
        try {
            Parent root = FXMLLoader.load(
                Main.class.getResource("/com/vis/fxml/Dashboard.fxml"));
            primaryStage.setScene(new Scene(root, 1280, 800));
            primaryStage.setMaximized(true);
        } catch (Exception e) {
            e.printStackTrace();
            com.vis.util.AlertUtil.error("Screen Error", "Could not load Dashboard screen: " + e.getMessage());
        }
    }

    public static void logout() {
        SessionManager.clear();
        showLogin();
    }

    public static void main(String[] args) { launch(args); }
}