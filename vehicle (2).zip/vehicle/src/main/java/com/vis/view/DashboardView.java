package com.vis.view;

import com.vis.dao.SystemLogDAO;
import com.vis.dao.VehicleDAO;
import com.vis.dao.DatabaseConnection;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import java.sql.*;

/**
 * Programmatic View for the Dashboard (Main Tab) with live charts and logs.
 */
public class DashboardView {

    public Node buildContent() {
        VBox root = new VBox(25);
        root.setPadding(new Insets(24));
        root.getStyleClass().add("content-area");

        // 1. Header
        Label title = new Label("System Dashboard");
        title.getStyleClass().add("page-title");
        Label sub = new Label("Real-time insights and system activity monitoring");
        sub.getStyleClass().add("page-subtitle");
        root.getChildren().addAll(title, sub);

        // 2. Stats Grid
        GridPane stats = new GridPane();
        stats.setHgap(20); stats.setVgap(20);
        stats.addRow(0, 
            createStatCard("Total Vehicles", "1,248", "indigo-card"),
            createStatCard("Active Reports", "84", "violet-card"),
            createStatCard("Open Inquiries", "12", "blue-card")
        );
        root.getChildren().add(stats);

        // 3. Charts Section
        HBox chartsRow = new HBox(20);
        chartsRow.setPrefHeight(350);
        
        // --- Pie Chart (Make Distribution) ---
        PieChart pieChart = new PieChart();
        pieChart.setTitle("Vehicles by Make");
        pieChart.setLegendSide(javafx.geometry.Side.RIGHT);
        loadPieData(pieChart);
        pieChart.getStyleClass().add("chart-container");
        HBox.setHgrow(pieChart, Priority.ALWAYS);

        // --- Bar Chart (Logins by Role) ---
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("User Role");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Total Logins");
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Logins per Role");
        loadBarData(barChart);
        barChart.setLegendVisible(false); // Clean look
        barChart.getStyleClass().add("role-login-chart");
        HBox.setHgrow(barChart, Priority.ALWAYS);

        chartsRow.getChildren().addAll(pieChart, barChart);
        root.getChildren().add(chartsRow);

        // 4. Recent Activity Table
        Label sectionTitle = new Label("Recent System Activity");
        sectionTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1E1B4B;");
        
        TableView<SystemLogDAO.LogEntry> logTable = new TableView<>();
        logTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        logTable.setPrefHeight(300);

        TableColumn<SystemLogDAO.LogEntry, String> colTime = new TableColumn<>("Time");
        colTime.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTime()));
        colTime.setPrefWidth(100);

        TableColumn<SystemLogDAO.LogEntry, String> colUser = new TableColumn<>("User");
        colUser.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getUserId()));
        colUser.setPrefWidth(120);

        TableColumn<SystemLogDAO.LogEntry, String> colAction = new TableColumn<>("Action");
        colAction.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getAction()));

        TableColumn<SystemLogDAO.LogEntry, String> colDetails = new TableColumn<>("Details");
        colDetails.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDetails()));

        logTable.getColumns().addAll(colTime, colUser, colAction, colDetails);

        try {
            SystemLogDAO dao = new SystemLogDAO();
            logTable.setItems(FXCollections.observableArrayList(dao.findRecent(15)));
        } catch (SQLException e) {
            logTable.setPlaceholder(new Label("No logs available yet."));
        }

        root.getChildren().addAll(sectionTitle, logTable);

        ScrollPane scroll = new ScrollPane(root);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color:transparent; -fx-background:transparent;");
        return scroll;
    }

    private void loadPieData(PieChart chart) {
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        String sql = "SELECT make, COUNT(*) as c FROM Vehicle GROUP BY make ORDER BY c DESC LIMIT 5";
        try (Connection c = DatabaseConnection.getConnection();
             Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) data.add(new PieChart.Data(rs.getString("make"), rs.getInt("c")));
            chart.setData(data);
        } catch (Exception e) { System.err.println("Pie error: " + e.getMessage()); }
    }

    private void loadBarData(BarChart<String, Number> chart) {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        String sql = "SELECT u.role, COUNT(*) as c " +
                     "FROM SystemLog l JOIN AppUser u ON l.user_id = u.user_id " +
                     "WHERE l.action = 'User Login' " +
                     "GROUP BY u.role ORDER BY c DESC";
        try (Connection c = DatabaseConnection.getConnection();
             Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) {
                XYChart.Data<String, Number> bar = new XYChart.Data<>(rs.getString("role"), rs.getInt("c"));
                series.getData().add(bar);
            }
            chart.getData().add(series);
        } catch (Exception e) { System.err.println("Bar error: " + e.getMessage()); }
    }

    private VBox createStatCard(String label, String value, String colorClass) {
        VBox card = new VBox(8);
        card.setPadding(new Insets(20));
        card.setPrefWidth(260);
        card.setStyle("-fx-background-color: white; -fx-background-radius: 12; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 10, 0, 0, 4); -fx-border-color: #E2E8F0; -fx-border-radius: 12;");
        Label lblVal = new Label(value);
        lblVal.setStyle("-fx-font-size: 28px; -fx-font-weight: 900; -fx-text-fill: #1E1B4B;");
        Label lblTxt = new Label(label);
        lblTxt.setStyle("-fx-text-fill: #64748B; -fx-font-weight: 600; -fx-font-size: 14px;");
        card.getChildren().addAll(lblVal, lblTxt);
        return card;
    }
}
