package com.vis.dao;

import com.vis.util.SessionManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SystemLogDAO {

    public static class LogEntry {
        private String time;
        private String userId;
        private String action;
        private String details;

        public LogEntry(String time, String userId, String action, String details) {
            this.time = time;
            this.userId = userId;
            this.action = action;
            this.details = details;
        }

        public String getTime() { return time; }
        public String getUserId() { return userId; }
        public String getAction() { return action; }
        public String getDetails() { return details; }
    }

    public static void log(String action, String details) {
        String userId = (SessionManager.getCurrentUser() != null) 
                        ? SessionManager.getCurrentUser().getUserId() : "System";
        String sql = "INSERT INTO SystemLog (user_id, action, details) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.setString(2, action);
            ps.setString(3, details);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Logging Error: " + e.getMessage());
        }
    }

    public List<LogEntry> findRecent(int limit) throws SQLException {
        List<LogEntry> list = new ArrayList<>();
        String sql = "SELECT TO_CHAR(log_time, 'HH24:MI:SS') as t, user_id, action, details " +
                     "FROM SystemLog ORDER BY log_id DESC LIMIT ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new LogEntry(
                        rs.getString("t"),
                        rs.getString("user_id"),
                        rs.getString("action"),
                        rs.getString("details")
                    ));
                }
            }
        }
        return list;
    }
}
