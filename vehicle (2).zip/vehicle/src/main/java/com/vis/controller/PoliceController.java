package com.vis.controller;

import com.vis.dao.PoliceReportDAO;
import com.vis.dao.VehicleDAO;
import com.vis.model.PoliceReport;
import com.vis.model.Vehicle;
import com.vis.util.AlertUtil;
import com.vis.util.SessionManager;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Optional;

/**
 * Controller for Police.fxml (Focused on Reports only).
 */
public class PoliceController {

    @FXML private TableView<PoliceReport>          reportTable;
    @FXML private TableColumn<PoliceReport,Number>  rColId;
    @FXML private TableColumn<PoliceReport,String>  rColReg;
    @FXML private TableColumn<PoliceReport,String>  rColDate;
    @FXML private TableColumn<PoliceReport,String>  rColType;
    @FXML private TableColumn<PoliceReport,String>  rColDesc;
    
    @FXML private Button addReportBtn;
    @FXML private Button editReportBtn;
    @FXML private Button deleteReportBtn;

    private final PoliceReportDAO reportDAO = new PoliceReportDAO();
    private final VehicleDAO vehicleDAO = new VehicleDAO();
    private final ObservableList<PoliceReport> reportData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        boolean canEdit = SessionManager.isAdmin() || SessionManager.isPolice();

        rColId.setCellValueFactory(c   -> new SimpleIntegerProperty(c.getValue().getReportId()));
        rColReg.setCellValueFactory(c  -> new SimpleStringProperty(c.getValue().getRegistrationNumber()));
        rColDate.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getReportDate() != null ? c.getValue().getReportDate().toString() : ""));
        rColType.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getReportType()));
        rColDesc.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDescription()));
        
        reportTable.setItems(reportData);
        refreshReports();

        if (addReportBtn != null) addReportBtn.setVisible(canEdit);
        if (editReportBtn != null) editReportBtn.setVisible(canEdit);
        if (deleteReportBtn != null) deleteReportBtn.setVisible(canEdit);
    }

    private void refreshReports() {
        try { reportData.setAll(reportDAO.findAll()); }
        catch (SQLException e) { AlertUtil.error("DB Error", e.getMessage()); }
    }

    @FXML private void handleAddReport() { showReportForm(null); }
    @FXML private void handleEditReport() {
        PoliceReport sel = reportTable.getSelectionModel().getSelectedItem();
        if (sel != null) showReportForm(sel);
    }
    @FXML private void handleDeleteReport() {
        PoliceReport sel = reportTable.getSelectionModel().getSelectedItem();
        if (sel != null && AlertUtil.confirm("Delete?", "Delete report #" + sel.getReportId() + "?")) {
            try { reportDAO.delete(sel.getReportId()); refreshReports(); }
            catch (SQLException e) { AlertUtil.error("Error", e.getMessage()); }
        }
    }

    private void showReportForm(PoliceReport existing) {
        boolean isEdit = existing != null;
        Dialog<PoliceReport> dlg = new Dialog<>();
        dlg.setTitle(isEdit ? "Edit Report" : "New Report");
        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));
        
        TextField regField = field(isEdit ? existing.getRegistrationNumber() : "");
        DatePicker date = new DatePicker(isEdit ? existing.getReportDate() : LocalDate.now());
        TextField type = field(isEdit ? existing.getReportType() : "");
        TextField desc = field(isEdit ? existing.getDescription() : "");
        
        grid.addRow(0, new Label("Reg No:"), regField);
        grid.addRow(1, new Label("Date:"), date);
        grid.addRow(2, new Label("Type:"), type);
        grid.addRow(3, new Label("Desc:"), desc);
        
        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        dlg.setResultConverter(b -> {
            if (b != ButtonType.OK) return null;
            PoliceReport r = isEdit ? existing : new PoliceReport();
            r.setRegistrationNumber(regField.getText().trim().toUpperCase());
            r.setReportDate(date.getValue());
            r.setReportType(type.getText().trim());
            r.setDescription(desc.getText().trim());
            return r;
        });

        dlg.showAndWait().ifPresent(r -> {
            try {
                if (isEdit) reportDAO.update(r);
                else {
                    Vehicle v = vehicleDAO.findByRegistration(r.getRegistrationNumber()).orElse(null);
                    if (v == null) { AlertUtil.error("Error", "Vehicle not found in registry."); return; }
                    reportDAO.create(v.getVehicleId(), r.getReportDate(), r.getReportType(), r.getDescription(), SessionManager.getCurrentUser().getFullName());
                }
                refreshReports();
            } catch (SQLException e) { AlertUtil.error("Error", e.getMessage()); }
        });
    }

    private TextField field(String val) {
        TextField f = new TextField(val);
        f.setStyle("-fx-background-color:#F5F3FF;-fx-border-color:#A5B4FC;-fx-border-radius:8;-fx-background-radius:8;-fx-padding:9 13;");
        f.setPrefWidth(220); return f;
    }
}