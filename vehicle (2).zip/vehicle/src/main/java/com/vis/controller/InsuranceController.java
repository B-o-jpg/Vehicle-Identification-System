package com.vis.controller;

import com.vis.dao.CustomerDAO;
import com.vis.dao.VehicleDAO;
import com.vis.model.Customer;
import com.vis.model.Vehicle;
import com.vis.util.AlertUtil;
import com.vis.util.SessionManager;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.sql.SQLException;

/**
 * Controller for Insurance.fxml.
 */
public class InsuranceController {

    @FXML private TableView<Vehicle>          insuranceTable;
    @FXML private TableColumn<Vehicle,Number>  colId;
    @FXML private TableColumn<Vehicle,String>  colReg;
    @FXML private TableColumn<Vehicle,String>  colMake;
    @FXML private TableColumn<Vehicle,String>  colModel;
    @FXML private TableColumn<Vehicle,Number>  colYear;
    @FXML private TableColumn<Vehicle,String>  colOwner;
    
    @FXML private TextField searchField;
    @FXML private Button addBtn;
    @FXML private Button editBtn;
    @FXML private Button deleteBtn;

    private final VehicleDAO dao = new VehicleDAO();
    private final ObservableList<Vehicle> data = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        boolean canEdit = SessionManager.isAdmin() || SessionManager.isInsurance();

        colId.setCellValueFactory(c    -> new SimpleIntegerProperty(c.getValue().getVehicleId()));
        colReg.setCellValueFactory(c   -> new SimpleStringProperty(c.getValue().getRegistrationNumber()));
        colMake.setCellValueFactory(c  -> new SimpleStringProperty(c.getValue().getMake()));
        colModel.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getModel()));
        colYear.setCellValueFactory(c  -> new SimpleIntegerProperty(c.getValue().getYear()));
        colOwner.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getOwnerName()));

        insuranceTable.setItems(data);
        refresh();

        if (addBtn != null) addBtn.setVisible(canEdit);
        if (editBtn != null) editBtn.setVisible(canEdit);
        if (deleteBtn != null) deleteBtn.setVisible(canEdit);

        // Live search filter
        if (searchField != null) {
            searchField.textProperty().addListener((obs, old, val) -> {
                if (val == null || val.isBlank()) { insuranceTable.setItems(data); return; }
                String lo = val.toLowerCase();
                ObservableList<Vehicle> filtered = FXCollections.observableArrayList();
                data.forEach(v -> {
                    if (v.getRegistrationNumber().toLowerCase().contains(lo) ||
                        v.getMake().toLowerCase().contains(lo) ||
                        v.getModel().toLowerCase().contains(lo))
                        filtered.add(v);
                });
                insuranceTable.setItems(filtered);
            });
        }
    }

    private void refresh() {
        try { data.setAll(dao.findAll()); }
        catch (SQLException e) { AlertUtil.error("DB Error", e.getMessage()); }
    }

    @FXML private void handleAdd() { showForm(null); }
    @FXML private void handleEdit() {
        Vehicle sel = insuranceTable.getSelectionModel().getSelectedItem();
        if (sel != null) showForm(sel);
        else AlertUtil.warn("No Selection", "Please select a vehicle.");
    }
    @FXML private void handleDelete() {
        Vehicle sel = insuranceTable.getSelectionModel().getSelectedItem();
        if (sel != null && AlertUtil.confirm("Remove", "Remove vehicle " + sel.getRegistrationNumber() + "?")) {
            try { dao.delete(sel.getVehicleId()); refresh(); }
            catch (SQLException e) { AlertUtil.error("Error", e.getMessage()); }
        }
        else if (sel == null) AlertUtil.warn("No Selection", "Please select a vehicle.");
    }

    private void showForm(Vehicle existing) {
        boolean isEdit = existing != null;
        Dialog<Vehicle> dlg = new Dialog<>();
        dlg.setTitle(isEdit ? "Edit Insurance Record" : "Register Vehicle");
        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));

        TextField regField = field(isEdit ? existing.getRegistrationNumber() : "");
        TextField makeField = field(isEdit ? existing.getMake() : "");
        TextField modField = field(isEdit ? existing.getModel() : "");
        TextField yearField = field(isEdit ? String.valueOf(existing.getYear()) : "");
        
        ComboBox<String> ownerBox = new ComboBox<>();
        java.util.Map<String,Integer> nameToId = new java.util.LinkedHashMap<>();
        try { for (Customer c : new CustomerDAO().findAll()) { String lbl = c.getName() + " ["+c.getId()+"]"; ownerBox.getItems().add(lbl); nameToId.put(lbl, c.getId()); if (isEdit && c.getId() == existing.getOwnerId()) ownerBox.setValue(lbl); } } catch (SQLException ignored){}

        grid.addRow(0, new Label("Reg:"), regField); grid.addRow(1, new Label("Make:"), makeField);
        grid.addRow(2, new Label("Model:"), modField); grid.addRow(3, new Label("Year:"), yearField);
        grid.addRow(4, new Label("Owner:"), ownerBox);

        dlg.getDialogPane().setContent(grid); dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dlg.setResultConverter(b -> {
            if (b != ButtonType.OK) return null;
            Vehicle v = isEdit ? existing : new Vehicle();
            v.setRegistrationNumber(regField.getText().trim().toUpperCase());
            v.setMake(makeField.getText().trim()); v.setModel(modField.getText().trim());
            v.setYear(Integer.parseInt(yearField.getText().trim()));
            Integer oid = nameToId.get(ownerBox.getValue()); v.setOwnerId(oid != null ? oid : 0);
            return v;
        });

        dlg.showAndWait().ifPresent(v -> {
            try {
                if (isEdit) dao.update(v);
                else dao.addVehicle(v.getRegistrationNumber(), v.getMake(), v.getModel(), v.getYear(), v.getOwnerId() == 0 ? null : v.getOwnerId());
                refresh();
            } catch (Exception e) { AlertUtil.error("Error", e.getMessage()); }
        });
    }

    private TextField field(String val) {
        TextField f = new TextField(val);
        f.setStyle("-fx-background-color:#F5F3FF;-fx-border-color:#A5B4FC;-fx-border-radius:8;-fx-background-radius:8;-fx-padding:9 13;");
        f.setPrefWidth(220); return f;
    }
}