package com.vis.controller;

import com.vis.dao.ServiceRecordDAO;
import com.vis.dao.VehicleDAO;
import com.vis.model.AppUser;
import com.vis.model.ServiceRecord;
import com.vis.model.Vehicle;
import com.vis.util.AlertUtil;
import com.vis.util.SessionManager;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * Controller for Workshop.fxml.
 * Full CRUD for ADMIN/WORKSHOP; read-only for CUSTOMER.
 */
public class WorkshopController {

    // ── FXML bindings ─────────────────────────────────────────────────────────
    @FXML private Label                            titleLabel;
    @FXML private Label                            subtitleLabel;
    @FXML private TableView<ServiceRecord>         workshopTable;
    @FXML private TableColumn<ServiceRecord,Number> colId;
    @FXML private TableColumn<ServiceRecord,String> colReg;
    @FXML private TableColumn<ServiceRecord,String> colDate;
    @FXML private TableColumn<ServiceRecord,String> colType;
    @FXML private TableColumn<ServiceRecord,String> colDesc;
    @FXML private TableColumn<ServiceRecord,Number> colCost;
    @FXML private Button                           addBtn;
    @FXML private Button                           editBtn;
    @FXML private Button                           deleteBtn;

    private final ServiceRecordDAO dao = new ServiceRecordDAO();
    private final ObservableList<ServiceRecord> data = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        AppUser user     = SessionManager.getCurrentUser();
        boolean isCustomer = SessionManager.isCustomer();
        boolean canEdit    = SessionManager.isAdmin() || SessionManager.isWorkshop();

        if (titleLabel    != null) titleLabel.setText(isCustomer ? "My Service Records" : "Service Records");
        if (subtitleLabel != null) subtitleLabel.setText(isCustomer
                ? "Service history for your vehicles" : "All workshop service records");

        colId.setCellValueFactory(c    -> new SimpleIntegerProperty(c.getValue().getServiceId()));
        colReg.setCellValueFactory(c   -> new SimpleStringProperty(c.getValue().getRegistrationNumber()));
        colDate.setCellValueFactory(c  -> new SimpleStringProperty(
                c.getValue().getServiceDate() != null ? c.getValue().getServiceDate().toString() : ""));
        colType.setCellValueFactory(c  -> new SimpleStringProperty(c.getValue().getServiceType()));
        colDesc.setCellValueFactory(c  -> new SimpleStringProperty(c.getValue().getDescription()));
        colCost.setCellValueFactory(c  -> new SimpleDoubleProperty(c.getValue().getCost()));

        workshopTable.setItems(data);
        refresh(user);

        if (addBtn    != null) addBtn.setVisible(canEdit);
        if (editBtn   != null) editBtn.setVisible(canEdit);
        if (deleteBtn != null) deleteBtn.setVisible(canEdit);
    }

    @FXML private void handleAdd()    { showForm(null); }
    @FXML private void handleEdit() {
        ServiceRecord sel = workshopTable.getSelectionModel().getSelectedItem();
        if (sel == null) { AlertUtil.warn("No Selection", "Select a record first."); return; }
        showForm(sel);
    }
    @FXML private void handleDelete() {
        ServiceRecord sel = workshopTable.getSelectionModel().getSelectedItem();
        if (sel == null) { AlertUtil.warn("No Selection", "Select a record to delete."); return; }
        if (AlertUtil.confirm("Confirm", "Delete service record #" + sel.getServiceId() + "?")) {
            try { dao.delete(sel.getServiceId()); refresh(SessionManager.getCurrentUser());
                  AlertUtil.info("Deleted", "Record deleted."); }
            catch (SQLException e) { AlertUtil.error("Error", e.getMessage()); }
        }
    }

    // ── Business logic API ────────────────────────────────────────────────────
    public List<ServiceRecord> getAll() throws SQLException { return dao.findAll(); }
    public List<ServiceRecord> getByCustomer(int cid) throws SQLException { return dao.findByCustomer(cid); }

    public void registerService(int vehicleId, LocalDate date, String type, String desc, double cost) throws SQLException {
        if (date == null)           throw new IllegalArgumentException("Date is required");
        if (type == null || type.isBlank()) throw new IllegalArgumentException("Service type is required");
        if (cost < 0)               throw new IllegalArgumentException("Cost cannot be negative");
        dao.registerService(vehicleId, date, type, desc, cost);
    }

    public void update(ServiceRecord sr) throws SQLException {
        if (sr.getServiceType() == null || sr.getServiceType().isBlank())
            throw new IllegalArgumentException("Type is required");
        dao.update(sr);
    }

    public void delete(int serviceId) throws SQLException { dao.delete(serviceId); }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void refresh(AppUser user) {
        try {
            List<ServiceRecord> list;
            if (SessionManager.isCustomer() && user != null && user.getCustomerId() != null)
                list = dao.findByCustomer(user.getCustomerId());
            else list = dao.findAll();
            data.setAll(list);
            workshopTable.setItems(data);
        } catch (SQLException e) { AlertUtil.error("DB Error", e.getMessage()); }
    }

    private void showForm(ServiceRecord existing) {
        boolean isEdit = existing != null;
        Dialog<ServiceRecord> dlg = new Dialog<>();
        dlg.setTitle(isEdit ? "Edit Service Record" : "New Service Record");

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));

        ComboBox<String> vehicleBox = new ComboBox<>();
        java.util.Map<String,Integer> regToId = new java.util.LinkedHashMap<>();
        try {
            for (Vehicle v : new VehicleDAO().findAll()) {
                String lbl = v.getRegistrationNumber() + " (" + v.getMake() + " " + v.getModel() + ")";
                vehicleBox.getItems().add(lbl);
                regToId.put(lbl, v.getVehicleId());
            }
        } catch (SQLException ignored) {}
        if (isEdit) vehicleBox.getItems().stream()
            .filter(s -> s.startsWith(existing.getRegistrationNumber()))
            .findFirst().ifPresent(vehicleBox::setValue);
        else if (!vehicleBox.getItems().isEmpty()) vehicleBox.setValue(vehicleBox.getItems().get(0));

        DatePicker datePicker = new DatePicker(isEdit ? existing.getServiceDate() : LocalDate.now());
        TextField typeField = field(isEdit ? existing.getServiceType()                       : "");
        TextField descField = field(isEdit ? existing.getDescription()                       : "");
        TextField costField = field(isEdit ? String.format("%.2f", existing.getCost())       : "0.00");

        grid.addRow(0, new Label("Vehicle:"),     vehicleBox);
        grid.addRow(1, new Label("Date:"),        datePicker);
        grid.addRow(2, new Label("Type:"),        typeField);
        grid.addRow(3, new Label("Description:"), descField);
        grid.addRow(4, new Label("Cost (R):"),    costField);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dlg.setResultConverter(btn -> {
            if (btn != ButtonType.OK) return null;
            try {
                ServiceRecord sr = isEdit ? existing : new ServiceRecord();
                String sel = vehicleBox.getValue();
                if (sel != null) sr.setVehicleId(regToId.get(sel));
                sr.setServiceDate(datePicker.getValue());
                sr.setServiceType(typeField.getText().trim());
                sr.setDescription(descField.getText().trim());
                sr.setCost(Double.parseDouble(costField.getText().trim()));
                return sr;
            } catch (NumberFormatException e) { AlertUtil.error("Input Error","Cost must be a number."); return null; }
        });
        dlg.showAndWait().ifPresent(sr -> {
            try {
                if (isEdit) dao.update(sr);
                else dao.registerService(sr.getVehicleId(), sr.getServiceDate(),
                        sr.getServiceType(), sr.getDescription(), sr.getCost());
                refresh(SessionManager.getCurrentUser());
                AlertUtil.info("Success", isEdit ? "Record updated." : "Service registered.");
            } catch (Exception e) { AlertUtil.error("Error", e.getMessage()); }
        });
    }

    private TextField field(String val) {
        TextField f = new TextField(val);
        f.setStyle("-fx-background-color:#F5F3FF;-fx-border-color:#A5B4FC;" +
                   "-fx-border-radius:8;-fx-background-radius:8;-fx-padding:9 13;");
        f.setPrefWidth(220); return f;
    }
}