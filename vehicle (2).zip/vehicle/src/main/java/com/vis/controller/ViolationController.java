package com.vis.controller;

import com.vis.dao.VehicleDAO;
import com.vis.dao.ViolationDAO;
import com.vis.model.Vehicle;
import com.vis.model.Violation;
import com.vis.util.AlertUtil;
import com.vis.util.SessionManager;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.sql.SQLException;
import java.time.LocalDate;

public class ViolationController {

    @FXML private TableView<Violation>              violationTable;
    @FXML private TableColumn<Violation,Number>     vColId;
    @FXML private TableColumn<Violation,String>     vColReg;
    @FXML private TableColumn<Violation,String>     vColDate;
    @FXML private TableColumn<Violation,String>     vColType;
    @FXML private TableColumn<Violation,Number>     vColFine;
    @FXML private TableColumn<Violation,String>     vColStatus;
    
    @FXML private Button addBtn;
    @FXML private Button editBtn;
    @FXML private Button deleteBtn;
    @FXML private Button markPaidBtn;

    private final ViolationDAO dao = new ViolationDAO();
    private final VehicleDAO vehicleDAO = new VehicleDAO();
    private final ObservableList<Violation> data = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        boolean canEdit = SessionManager.isAdmin() || SessionManager.isPolice();

        vColId.setCellValueFactory(c     -> new SimpleIntegerProperty(c.getValue().getViolationId()));
        vColReg.setCellValueFactory(c    -> new SimpleStringProperty(c.getValue().getRegistrationNumber()));
        vColDate.setCellValueFactory(c   -> new SimpleStringProperty(
                c.getValue().getViolationDate() != null ? c.getValue().getViolationDate().toString() : ""));
        vColType.setCellValueFactory(c   -> new SimpleStringProperty(c.getValue().getViolationType()));
        vColFine.setCellValueFactory(c   -> new SimpleDoubleProperty(c.getValue().getFineAmount()));
        vColStatus.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStatus()));

        violationTable.setItems(data);
        refresh();

        if (addBtn != null) addBtn.setVisible(canEdit);
        if (editBtn != null) editBtn.setVisible(canEdit);
        if (deleteBtn != null) deleteBtn.setVisible(canEdit);
        if (markPaidBtn != null) markPaidBtn.setVisible(canEdit);
    }

    private void refresh() {
        try { data.setAll(dao.findAll()); }
        catch (SQLException e) { AlertUtil.error("DB Error", e.getMessage()); }
    }

    @FXML private void handleAdd() { showForm(null); }
    @FXML private void handleEdit() {
        Violation sel = violationTable.getSelectionModel().getSelectedItem();
        if (sel != null) showForm(sel);
    }
    @FXML private void handleDelete() {
        Violation sel = violationTable.getSelectionModel().getSelectedItem();
        if (sel != null && AlertUtil.confirm("Delete?", "Delete violation #" + sel.getViolationId() + "?")) {
            try { dao.delete(sel.getViolationId()); refresh(); }
            catch (SQLException e) { AlertUtil.error("Error", e.getMessage()); }
        }
    }
    @FXML private void handleMarkPaid() {
        Violation sel = violationTable.getSelectionModel().getSelectedItem();
        if (sel != null) {
            try { dao.payViolation(sel.getViolationId()); refresh(); }
            catch (SQLException e) { AlertUtil.error("Error", e.getMessage()); }
        }
    }

    private void showForm(Violation existing) {
        boolean isEdit = existing != null;
        Dialog<Violation> dlg = new Dialog<>();
        dlg.setTitle(isEdit ? "Edit Violation" : "Issue Violation");
        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));
        
        TextField regField = field(isEdit ? existing.getRegistrationNumber() : "");
        DatePicker date = new DatePicker(isEdit ? existing.getViolationDate() : LocalDate.now());
        TextField type = field(isEdit ? existing.getViolationType() : "");
        TextField fine = field(isEdit ? String.valueOf(existing.getFineAmount()) : "0.00");
        
        grid.addRow(0, new Label("Reg No:"), regField);
        grid.addRow(1, new Label("Date:"), date);
        grid.addRow(2, new Label("Type:"), type);
        grid.addRow(3, new Label("Fine:"), fine);
        
        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        dlg.setResultConverter(b -> {
            if (b != ButtonType.OK) return null;
            Violation v = isEdit ? existing : new Violation();
            v.setRegistrationNumber(regField.getText().trim().toUpperCase());
            v.setViolationDate(date.getValue());
            v.setViolationType(type.getText().trim());
            v.setFineAmount(Double.parseDouble(fine.getText().trim()));
            v.setStatus(isEdit ? existing.getStatus() : "Unpaid");
            return v;
        });

        dlg.showAndWait().ifPresent(v -> {
            try {
                if (isEdit) dao.update(v);
                else {
                    Vehicle veh = vehicleDAO.findByRegistration(v.getRegistrationNumber()).orElse(null);
                    if (veh == null) { AlertUtil.error("Error", "Vehicle not found."); return; }
                    dao.create(veh.getVehicleId(), v.getViolationDate(), v.getViolationType(), v.getFineAmount(), v.getStatus());
                }
                refresh();
            } catch (Exception e) { AlertUtil.error("Error", e.getMessage()); }
        });
    }

    private TextField field(String val) {
        TextField f = new TextField(val);
        f.setStyle("-fx-background-color:#F5F3FF;-fx-border-color:#A5B4FC;-fx-border-radius:8;-fx-background-radius:8;-fx-padding:9 13;");
        f.setPrefWidth(220); return f;
    }
}
