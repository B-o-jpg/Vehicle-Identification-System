package com.vis.controller;

import com.vis.dao.CustomerDAO;
import com.vis.model.Customer;
import com.vis.util.AlertUtil;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.sql.SQLException;
import java.util.List;

/**
 * Controller for Customer.fxml (ADMIN-only).
 * Also keeps the original business-logic API for use by other controllers.
 */
public class CustomerController {

    // ── FXML bindings ─────────────────────────────────────────────────────────
    @FXML private TableView<Customer>         customerTable;
    @FXML private TableColumn<Customer,Number> colId;
    @FXML private TableColumn<Customer,String> colName;
    @FXML private TableColumn<Customer,String> colAddress;
    @FXML private TableColumn<Customer,String> colPhone;
    @FXML private TableColumn<Customer,String> colEmail;

    private final CustomerDAO dao = new CustomerDAO();
    private final ObservableList<Customer> data = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(c      -> new SimpleIntegerProperty(c.getValue().getId()));
        colName.setCellValueFactory(c    -> new SimpleStringProperty(c.getValue().getName()));
        colAddress.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getAddress()));
        colPhone.setCellValueFactory(c   -> new SimpleStringProperty(c.getValue().getPhone()));
        colEmail.setCellValueFactory(c   -> new SimpleStringProperty(c.getValue().getEmail()));
        customerTable.setItems(data);
        refresh();
    }

    @FXML private void handleAdd()    { showForm(null); }
    @FXML private void handleEdit() {
        Customer sel = customerTable.getSelectionModel().getSelectedItem();
        if (sel == null) { AlertUtil.warn("No Selection", "Please select a customer first."); return; }
        showForm(sel);
    }
    @FXML private void handleDelete() {
        Customer sel = customerTable.getSelectionModel().getSelectedItem();
        if (sel == null) { AlertUtil.warn("No Selection", "Please select a customer to delete."); return; }
        if (AlertUtil.confirm("Confirm Delete", "Delete customer '" + sel.getName() + "'? This cannot be undone.")) {
            try { dao.delete(sel.getId()); refresh(); AlertUtil.info("Deleted", "Customer deleted."); }
            catch (SQLException e) { AlertUtil.error("Error", e.getMessage()); }
        }
    }

    // ── Business logic (reused by other controllers) ──────────────────────────
    public List<Customer> getAll() throws SQLException { return dao.findAll(); }

    public void create(Customer c) throws SQLException {
        if (c.getName() == null || c.getName().isBlank()) throw new IllegalArgumentException("Name is required");
        dao.create(c);
    }

    public void update(Customer c) throws SQLException {
        if (c.getName() == null || c.getName().isBlank()) throw new IllegalArgumentException("Name is required");
        dao.update(c);
    }

    public void delete(int customerId) throws SQLException { dao.delete(customerId); }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void refresh() {
        try { data.setAll(dao.findAll()); customerTable.setItems(data); }
        catch (SQLException e) { AlertUtil.error("DB Error", e.getMessage()); }
    }

    private void showForm(Customer existing) {
        boolean isEdit = existing != null;
        Dialog<Customer> dialog = new Dialog<>();
        dialog.setTitle(isEdit ? "Edit Customer" : "Add Customer");
        dialog.setHeaderText(isEdit ? "Update customer details" : "Enter new customer details");

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));

        TextField nameField    = field(isEdit ? existing.getName()    : "");
        TextField addressField = field(isEdit ? existing.getAddress() : "");
        TextField phoneField   = field(isEdit ? existing.getPhone()   : "");
        TextField emailField   = field(isEdit ? existing.getEmail()   : "");

        grid.addRow(0, new Label("Name:"),    nameField);
        grid.addRow(1, new Label("Address:"), addressField);
        grid.addRow(2, new Label("Phone:"),   phoneField);
        grid.addRow(3, new Label("Email:"),   emailField);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.setResultConverter(btn -> {
            if (btn != ButtonType.OK) return null;
            Customer c = isEdit ? existing : new Customer();
            c.setName(nameField.getText().trim());
            c.setAddress(addressField.getText().trim());
            c.setPhone(phoneField.getText().trim());
            c.setEmail(emailField.getText().trim());
            return c;
        });
        dialog.showAndWait().ifPresent(c -> {
            try {
                if (isEdit) dao.update(c); else dao.create(c);
                refresh();
                AlertUtil.info("Success", isEdit ? "Customer updated." : "Customer added.");
            } catch (Exception e) { AlertUtil.error("Error", e.getMessage()); }
        });
    }

    private TextField field(String val) {
        TextField f = new TextField(val);
        f.setStyle("-fx-background-color:#F5F3FF;-fx-border-color:#A5B4FC;" +
                   "-fx-border-radius:8;-fx-background-radius:8;-fx-padding:9 13;");
        f.setPrefWidth(220); return f;
    }
}