package com.vis.controller;

import com.vis.Main;
import com.vis.model.AppUser;
import com.vis.util.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import com.vis.util.AlertUtil;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

/**
 * Controller for Dashboard.fxml.
 * Populates the sidebar nav dynamically based on the logged-in user's role.
 */
public class DashboardController {

    @FXML private VBox       navBox;
    @FXML private Label      sidebarRoleBadge;
    @FXML private Label      sidebarName;
    @FXML private StackPane  contentPane;

    @FXML
    public void initialize() {
        AppUser user = SessionManager.getCurrentUser();
        if (user == null) { Main.showLogin(); return; }

        sidebarRoleBadge.setText(user.getRole().name());
        sidebarName.setText(user.getFullName());

        String r = user.getRole().name();
        switch (r) {
            case "ADMIN" -> {
                addNav("Dashboard",       "DASHBOARD");
                addNav("User Management", "ADMIN");
                addNav("Customers",       "CUSTOMERS");
                addNav("Vehicles",        "VEHICLES");
                addNav("Service Records", "WORKSHOP");
                addNav("Police Reports",  "POLICE");
                addNav("Violations",      "VIOLATION");
                addNav("Insurance",       "INSURANCE");
            }
            case "CUSTOMER" -> {
                addNav("Dashboard",          "DASHBOARD");
                addNav("My Vehicles",        "VEHICLES");
                addNav("My Service Records", "WORKSHOP");
                addNav("My Police Reports",  "POLICE");
            }
            case "POLICE" -> {
                addNav("Dashboard",       "DASHBOARD");
                addNav("Police Reports",  "POLICE");
                addNav("Violations",      "VIOLATION");
                addNav("Browse Vehicles", "VEHICLES");
            }
            case "INSURANCE" -> {
                addNav("Dashboard",          "DASHBOARD");
                addNav("Insurance Registry", "INSURANCE");
                addNav("Vehicles",           "VEHICLES");
            }
            case "WORKSHOP" -> {
                addNav("Dashboard",       "DASHBOARD");
                addNav("Service Records", "WORKSHOP");
                addNav("Vehicles",        "VEHICLES");
            }
        }

        loadContent("DASHBOARD");
    }

    @FXML private void handleExit() { Platform.exit(); System.exit(0); }
    @FXML private void handleAbout() { AlertUtil.info("About VIS", "Vehicle Identification System v1.0"); }
    @FXML private void handleLogout() { Main.logout(); }

    private void addNav(String label, String action) {
        Button b = new Button(label);
        b.setMaxWidth(Double.MAX_VALUE);
        b.getStyleClass().add("sidebar-nav-btn");
        b.setOnAction(e -> loadContent(action));
        navBox.getChildren().add(b);
    }

    private void loadContent(String action) {
        try {
            Node view;
            if ("DASHBOARD".equals(action)) {
                view = new com.vis.view.DashboardView().buildContent();
            } else {
                String fxml = switch (action) {
                    case "ADMIN"     -> "Admin.fxml";
                    case "CUSTOMERS" -> "Customer.fxml";
                    case "VEHICLES"  -> "Vehicle.fxml";
                    case "WORKSHOP"  -> "Workshop.fxml";
                    case "POLICE"    -> "Police.fxml";
                    case "VIOLATION" -> "Violation.fxml";
                    case "INSURANCE" -> "Insurance.fxml";
                    default          -> null;
                };
                if (fxml == null) return;
                view = FXMLLoader.load(Main.class.getResource("/com/vis/fxml/" + fxml));
            }
            contentPane.getChildren().setAll(view);
        } catch (Exception e) {
            e.printStackTrace();
            Label err = new Label("Could not load view [" + action + "]: " + e.getMessage());
            err.setStyle("-fx-text-fill: #EF4444; -fx-font-weight: bold; -fx-padding: 20;");
            contentPane.getChildren().setAll(err);
        }
    }
}
