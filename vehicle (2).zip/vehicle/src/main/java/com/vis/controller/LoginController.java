package com.vis.controller;

import com.vis.dao.AppUserDAO;
import com.vis.model.AppUser;
import com.vis.util.SessionManager;
import com.vis.Main;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.SQLException;
import java.util.Optional;

/**
 * Controller for Login.fxml and Register.fxml.
 * Handles authentication and new-user registration.
 */
public class LoginController {

    // ── Login.fxml bindings ───────────────────────────────────────────────────
    @FXML private TextField     userIdField;
    @FXML private PasswordField passwordField;
    @FXML private Label         errorLabel;

    // ── Register.fxml bindings ────────────────────────────────────────────────
    @FXML private TextField     regUserIdField;
    @FXML private PasswordField regPasswordField;
    @FXML private PasswordField regConfirmField;
    @FXML private TextField     regFullNameField;
    @FXML private TextField     regEmailField;
    @FXML private TextField     regPhoneField;
    @FXML private TextField     regAddressField;
    @FXML private ComboBox<String> regRoleBox;
    @FXML private Label         regErrorLabel;

    private final AppUserDAO userDAO = new AppUserDAO();

    // ── FXML handlers ─────────────────────────────────────────────────────────

    @FXML
    private void handleLogin() {
        errorLabel.setText("");
        try {
            Optional<AppUser> user = login(userIdField.getText(), passwordField.getText());
            if (user.isPresent()) Main.showDashboard();
            else errorLabel.setText("Invalid credentials. Please try again.");
        } catch (IllegalArgumentException ex) {
            errorLabel.setText(ex.getMessage());
        } catch (SQLException ex) {
            errorLabel.setText("Database error: " + ex.getMessage());
        }
    }

    @FXML
    private void handleRegister() {
        if (regErrorLabel == null) {
            // Called from Login.fxml "Create Account" button → navigate to register screen
            Main.showRegister();
            return;
        }
        regErrorLabel.setText("");
        String uid    = regUserIdField.getText().trim();
        String pass   = regPasswordField.getText();
        String conf   = regConfirmField.getText();
        String name   = regFullNameField.getText().trim();
        String email  = regEmailField.getText().trim();
        String phone  = regPhoneField.getText().trim();
        String addr   = regAddressField.getText().trim();
        String role   = regRoleBox.getValue();

        if (uid.isBlank() || pass.isBlank() || name.isBlank()) {
            regErrorLabel.setText("User ID, password, and full name are required."); return;
        }
        if (!pass.equals(conf)) {
            regErrorLabel.setText("Passwords do not match."); return;
        }
        if (pass.length() < 6) {
            regErrorLabel.setText("Password must be at least 6 characters."); return;
        }
        try {
            register(uid, pass, role, name, addr, phone, email);
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Account '" + uid + "' created as " + role + ".\nYou can now log in.",
                    ButtonType.OK);
            alert.setTitle("Registration Successful");
            alert.showAndWait();
            Main.showLogin();
        } catch (IllegalArgumentException ex) {
            regErrorLabel.setText(ex.getMessage());
        } catch (Exception ex) {
            regErrorLabel.setText("Registration failed: " + ex.getMessage());
        }
    }

    @FXML
    private void handleBackToLogin() {
        Main.showLogin();
    }

    // ── Business logic (reusable by other controllers) ────────────────────────

    public Optional<AppUser> login(String userId, String password) throws SQLException {
        if (userId == null || userId.isBlank() || password == null || password.isBlank())
            throw new IllegalArgumentException("User ID and password are required");
        Optional<AppUser> user = userDAO.authenticate(userId.trim(), password);
        user.ifPresent(u -> {
            SessionManager.setCurrentUser(u);
            com.vis.dao.SystemLogDAO.log("User Login", u.getFullName() + " logged in.");
        });
        return user;
    }

    public void register(String userId, String password, String role, String fullName,
                         String address, String phone, String email) throws SQLException {
        if (userId == null || userId.isBlank())
            throw new IllegalArgumentException("User ID is required");
        if (password == null || password.length() < 6)
            throw new IllegalArgumentException("Password must be at least 6 characters");
        userDAO.register(userId.trim(), password, role, fullName, address, phone, email);
    }
}