package com.vis.controller;

import com.vis.dao.CustomerDAO;
import com.vis.dao.VehicleDAO;
import com.vis.model.AppUser;
import com.vis.model.Customer;
import com.vis.model.Vehicle;
import com.vis.util.AlertUtil;
import com.vis.util.SessionManager;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/**
 * Controller for Vehicle.fxml.
 * Read-write for ADMIN/WORKSHOP/POLICE/INSURANCE; read-only for CUSTOMER.
 */
public class VehicleController {

    // ── FXML bindings ─────────────────────────────────────────────────────────
    @FXML private Label                        titleLabel;
    @FXML private Label                        subtitleLabel;
    @FXML private TableView<Vehicle>           vehicleTable;
    @FXML private TableColumn<Vehicle,Number>  colId;
    @FXML private TableColumn<Vehicle,String>  colReg;
    @FXML private TableColumn<Vehicle,String>  colMake;
    @FXML private TableColumn<Vehicle,String>  colModel;
    @FXML private TableColumn<Vehicle,Number>  colYear;
    @FXML private TableColumn<Vehicle,String>  colOwner;
    @FXML private TextField                    searchField;
    @FXML private Button                       addBtn;
    @FXML private Button                       editBtn;
    @FXML private Button                       deleteBtn;

    private final VehicleDAO dao = new VehicleDAO();
    private final ObservableList<Vehicle> data = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        AppUser user     = SessionManager.getCurrentUser();
        boolean isCustomer = SessionManager.isCustomer();

        if (titleLabel    != null) titleLabel.setText(isCustomer ? "My Vehicles" : "All Vehicles");
        if (subtitleLabel != null) subtitleLabel.setText(isCustomer
                ? "Vehicles registered under your account" : "Manage the full vehicle fleet");

        colId.setCellValueFactory(c    -> new SimpleIntegerProperty(c.getValue().getVehicleId()));
        colReg.setCellValueFactory(c   -> new SimpleStringProperty(c.getValue().getRegistrationNumber()));
        colMake.setCellValueFactory(c  -> new SimpleStringProperty(c.getValue().getMake()));
        colModel.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getModel()));
        colYear.setCellValueFactory(c  -> new SimpleIntegerProperty(c.getValue().getYear()));
        colOwner.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getOwnerName()));

        vehicleTable.setItems(data);
        refresh(user);

        // Hide add/edit/delete for read-only roles
        boolean canEdit = SessionManager.isAdmin() || SessionManager.isWorkshop() || SessionManager.isPolice() || SessionManager.isInsurance();
        if (addBtn    != null) addBtn.setVisible(canEdit);
        if (editBtn   != null) editBtn.setVisible(!isCustomer);
        if (deleteBtn != null) deleteBtn.setVisible(canEdit);

        // Live search
        if (searchField != null) {
            searchField.textProperty().addListener((obs, old, val) -> {
                if (val == null || val.isBlank()) { vehicleTable.setItems(data); return; }
                String lo = val.toLowerCase();
                ObservableList<Vehicle> f = FXCollections.observableArrayList();
                data.forEach(v -> {
                    if (v.getRegistrationNumber().toLowerCase().contains(lo)
                     || v.getMake().toLowerCase().contains(lo)
                     || v.getModel().toLowerCase().contains(lo)) f.add(v);
                });
                vehicleTable.setItems(f);
            });
        }
    }

    @FXML private void handleAdd()    { showForm(null); }
    @FXML private void handleEdit() {
        Vehicle sel = vehicleTable.getSelectionModel().getSelectedItem();
        if (sel == null) { AlertUtil.warn("No Selection", "Please select a vehicle."); return; }
        showForm(sel);
    }
    @FXML private void handleDelete() {
        Vehicle sel = vehicleTable.getSelectionModel().getSelectedItem();
        if (sel == null) { AlertUtil.warn("No Selection", "Please select a vehicle."); return; }
        boolean canDelete = SessionManager.isAdmin() || SessionManager.isPolice() || SessionManager.isInsurance();
        if (!canDelete) { AlertUtil.warn("Permission Denied", "Only admins, police or insurance agents can delete vehicles."); return; }
        if (AlertUtil.confirm("Confirm Delete", "Delete vehicle " + sel.getRegistrationNumber() + "?")) {
            try { delete(sel.getVehicleId()); refresh(SessionManager.getCurrentUser());
                  AlertUtil.info("Deleted", "Vehicle deleted."); }
            catch (SQLException e) { AlertUtil.error("Error", e.getMessage()); }
        }
    }

    // ── Business logic API ────────────────────────────────────────────────────
    public List<Vehicle> getAll() throws SQLException { return dao.findAll(); }
    public List<Vehicle> getByCustomer(int customerId) throws SQLException { return dao.findByCustomer(customerId); }
    public Optional<Vehicle> findByReg(String reg) throws SQLException { return dao.findByRegistration(reg); }

    public void addVehicle(String reg, String make, String model, int year, Integer ownerId) throws SQLException {
        if (reg == null || reg.isBlank()) throw new IllegalArgumentException("Registration is required");
        if (year < 1900 || year > 2100)  throw new IllegalArgumentException("Year out of range");
        dao.addVehicle(reg.trim().toUpperCase(), make, model, year, ownerId);
        com.vis.dao.SystemLogDAO.log("Vehicle Added", "New vehicle " + reg.toUpperCase() + " registered.");
    }

    public void update(Vehicle v) throws SQLException {
        if (v.getRegistrationNumber() == null || v.getRegistrationNumber().isBlank())
            throw new IllegalArgumentException("Registration is required");
        dao.update(v);
        com.vis.dao.SystemLogDAO.log("Vehicle Updated", "Vehicle " + v.getRegistrationNumber() + " details updated.");
    }

    public void delete(int vehicleId) throws SQLException { 
        dao.delete(vehicleId);
        com.vis.dao.SystemLogDAO.log("Vehicle Deleted", "Vehicle ID " + vehicleId + " removed from registry.");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void refresh(AppUser user) {
        try {
            List<Vehicle> list;
            if (SessionManager.isCustomer() && user != null && user.getCustomerId() != null)
                list = dao.findByCustomer(user.getCustomerId());
            else list = dao.findAll();
            data.setAll(list);
            vehicleTable.setItems(data);
        } catch (SQLException e) { AlertUtil.error("DB Error", e.getMessage()); }
    }

    private void showForm(Vehicle existing) {
        boolean isEdit = existing != null;
        Dialog<Vehicle> dlg = new Dialog<>();
        dlg.setTitle(isEdit ? "Edit Vehicle" : "Add Vehicle");

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));

        TextField regField  = field(isEdit ? existing.getRegistrationNumber() : "");
        TextField makeField = field(isEdit ? existing.getMake()               : "");
        TextField modField  = field(isEdit ? existing.getModel()              : "");
        TextField yearField = field(isEdit ? String.valueOf(existing.getYear()): "");

        ComboBox<String> ownerBox = new ComboBox<>();
        ownerBox.getItems().add("(None)");
        java.util.Map<String,Integer> nameToId = new java.util.LinkedHashMap<>();
        nameToId.put("(None)", null);
        try {
            for (Customer c : new CustomerDAO().findAll()) {
                String lbl = c.getName() + " [" + c.getId() + "]";
                nameToId.put(lbl, c.getId());
                ownerBox.getItems().add(lbl);
            }
        } catch (SQLException ignored) {}
        if (isEdit) {
            ownerBox.getItems().stream()
                .filter(n -> n.endsWith("[" + existing.getOwnerId() + "]"))
                .findFirst().ifPresent(ownerBox::setValue);
        } else ownerBox.setValue("(None)");

        grid.addRow(0, new Label("Registration:"), regField);
        grid.addRow(1, new Label("Make:"),         makeField);
        grid.addRow(2, new Label("Model:"),        modField);
        grid.addRow(3, new Label("Year:"),         yearField);
        grid.addRow(4, new Label("Owner:"),        ownerBox);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dlg.setResultConverter(btn -> {
            if (btn != ButtonType.OK) return null;
            try {
                Vehicle v = isEdit ? existing : new Vehicle();
                v.setRegistrationNumber(regField.getText().trim().toUpperCase());
                v.setMake(makeField.getText().trim());
                v.setModel(modField.getText().trim());
                v.setYear(Integer.parseInt(yearField.getText().trim()));
                Integer oid = nameToId.get(ownerBox.getValue());
                v.setOwnerId(oid != null ? oid : 0);
                return v;
            } catch (NumberFormatException e) { AlertUtil.error("Input Error","Year must be a number."); return null; }
        });
        dlg.showAndWait().ifPresent(v -> {
            try {
                if (isEdit) update(v);
                else addVehicle(v.getRegistrationNumber(), v.getMake(), v.getModel(), v.getYear(),
                                     v.getOwnerId() == 0 ? null : v.getOwnerId());
                refresh(SessionManager.getCurrentUser());
                AlertUtil.info("Success", isEdit ? "Vehicle updated." : "Vehicle added.");
            } catch (Exception e) { AlertUtil.error("Error", e.getMessage()); }
        });
    }

    private TextField field(String val) {
        TextField f = new TextField(val);
        f.setStyle("-fx-background-color:#F5F3FF;-fx-border-color:#A5B4FC;" +
                   "-fx-border-radius:8;-fx-background-radius:8;-fx-padding:9 13;");
        f.setPrefWidth(220); return f;
    }
}