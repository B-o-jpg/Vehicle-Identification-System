package com.vis.model;

  import javafx.beans.property.SimpleDoubleProperty;
  import javafx.beans.property.SimpleIntegerProperty;
  import javafx.beans.property.SimpleStringProperty;
  import java.time.LocalDate;

  public class Violation implements Reportable {
      private int violationId;
      private int vehicleId;
      private String registrationNumber;
      private LocalDate violationDate;
      private String violationType;
      private double fineAmount;
      private String status;
      private String officerName;


      public Violation() {}
      public int getViolationId()                { return violationId; }
      public void setViolationId(int id)         { this.violationId = id; }
      public int getVehicleId()                  { return vehicleId; }
      public void setVehicleId(int v)            { this.vehicleId = v; }
      public String getRegistrationNumber()      { return registrationNumber; }
      public void setRegistrationNumber(String r){ this.registrationNumber = r; }
      public LocalDate getViolationDate()        { return violationDate; }
      public void setViolationDate(LocalDate d)  { this.violationDate = d; }
      public String getViolationType()           { return violationType; }
      public void setViolationType(String t)     { this.violationType = t; }
      public double getFineAmount()              { return fineAmount; }
      public void setFineAmount(double f)        { this.fineAmount = f; }
      public String getStatus()                  { return status; }
      public void setStatus(String s)            { this.status = s; }
      @Override public String getSummary() { return violationType+" on "+violationDate+" — R"+String.format("%.2f",fineAmount)+" ("+status+")"; }
      @Override public String getCategory() { return "Traffic Violation"; }
      public String getOfficerName()           { return officerName; }
      public void setOfficerName(String n)     { this.officerName = n; }


      public SimpleIntegerProperty violationIdProperty()         { return new SimpleIntegerProperty(violationId); }
      public SimpleIntegerProperty vehicleIdProperty()           { return new SimpleIntegerProperty(vehicleId); }
      public SimpleStringProperty registrationNumberProperty()   { return new SimpleStringProperty(registrationNumber); }
      public SimpleStringProperty violationDateProperty()        { return new SimpleStringProperty(violationDate==null?"":violationDate.toString()); }
      public SimpleStringProperty violationTypeProperty()        { return new SimpleStringProperty(violationType); }
      public SimpleDoubleProperty fineAmountProperty()           { return new SimpleDoubleProperty(fineAmount); }
      public SimpleStringProperty statusProperty()               { return new SimpleStringProperty(status); }
      public SimpleStringProperty officerNameProperty()           { return new SimpleStringProperty(officerName == null ? "" : officerName); }
  }
  