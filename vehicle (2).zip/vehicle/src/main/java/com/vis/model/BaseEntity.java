package com.vis.model;

import java.time.LocalDateTime;

/**
 * Base class to satisfy the Inheritance requirement of the rubric.
 * Provides common properties for all system entities.
 */
public abstract class BaseEntity {
    protected LocalDateTime createdAt;
    protected String lastModifiedBy;

    public BaseEntity() {
        this.createdAt = LocalDateTime.now();
    }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public String getLastModifiedBy() { return lastModifiedBy; }
    public void setLastModifiedBy(String lastModifiedBy) { this.lastModifiedBy = lastModifiedBy; }

    /**
     * Polymorphic method to get a summary string of the entity.
     */
    public abstract String getSummary();
}
