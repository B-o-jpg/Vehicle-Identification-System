-- =============================================================
--  Vehicle Identification System  –  PostgreSQL Schema (Final)
-- =============================================================

DROP VIEW  IF EXISTS vw_vehicle_full_details   CASCADE;
DROP VIEW  IF EXISTS vw_outstanding_violations CASCADE;
DROP VIEW  IF EXISTS vw_service_history        CASCADE;
DROP TABLE IF EXISTS SystemLog    CASCADE;
DROP TABLE IF EXISTS Violation       CASCADE;
DROP TABLE IF EXISTS PoliceReport    CASCADE;
DROP TABLE IF EXISTS CustomerQuery   CASCADE;
DROP TABLE IF EXISTS ServiceRecord   CASCADE;
DROP TABLE IF EXISTS Vehicle         CASCADE;
DROP TABLE IF EXISTS AppUser         CASCADE;
DROP TABLE IF EXISTS Customer        CASCADE;

-- ─────────────────────────────────────────────────────────────
--  TABLES
-- ─────────────────────────────────────────────────────────────

-- Customer must come before AppUser because AppUser references it
CREATE TABLE Customer (
    customer_id  SERIAL       PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    address      VARCHAR(255),
    phone        VARCHAR(20),
    email        VARCHAR(100)
);

CREATE TABLE AppUser (
    user_id      VARCHAR(50)  PRIMARY KEY,
    password     VARCHAR(100) NOT NULL,
    role         VARCHAR(20)  NOT NULL
                 CHECK (role IN ('ADMIN','WORKSHOP','CUSTOMER','POLICE','INSURANCE')),
    full_name    VARCHAR(100) NOT NULL,
    active       BOOLEAN      DEFAULT TRUE,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    customer_id  INTEGER      REFERENCES Customer(customer_id) ON DELETE SET NULL
);

CREATE TABLE Vehicle (
    vehicle_id           SERIAL      PRIMARY KEY,
    registration_number  VARCHAR(20) UNIQUE NOT NULL,
    make                 VARCHAR(50),
    model                VARCHAR(50),
    year                 INTEGER,
    customer_id          INTEGER REFERENCES Customer(customer_id) ON DELETE SET NULL
);

CREATE TABLE ServiceRecord (
    service_id    SERIAL        PRIMARY KEY,
    vehicle_id    INTEGER REFERENCES Vehicle(vehicle_id) ON DELETE CASCADE,
    service_date  DATE          NOT NULL,
    service_type  VARCHAR(50),
    description   TEXT,
    cost          NUMERIC(10,2)
);

CREATE TABLE CustomerQuery (
    query_id      SERIAL        PRIMARY KEY,
    customer_id   INTEGER REFERENCES Customer(customer_id) ON DELETE CASCADE,
    vehicle_id    INTEGER REFERENCES Vehicle(vehicle_id)   ON DELETE CASCADE,
    query_date    DATE          NOT NULL,
    query_text    TEXT,
    response_text TEXT
);

CREATE TABLE PoliceReport (
    report_id     SERIAL        PRIMARY KEY,
    vehicle_id    INTEGER REFERENCES Vehicle(vehicle_id) ON DELETE CASCADE,
    report_date   DATE          NOT NULL,
    report_type   VARCHAR(50),
    description   TEXT,
    officer_name  VARCHAR(100)
);

CREATE TABLE Violation (
    violation_id    SERIAL        PRIMARY KEY,
    vehicle_id      INTEGER REFERENCES Vehicle(vehicle_id) ON DELETE CASCADE,
    violation_date  DATE          NOT NULL,
    violation_type  VARCHAR(50),
    fine_amount     NUMERIC(10,2),
    status          VARCHAR(10) CHECK (status IN ('Paid','Unpaid'))
);

CREATE TABLE SystemLog (
    log_id      SERIAL      PRIMARY KEY,
    log_time    TIMESTAMP   DEFAULT CURRENT_TIMESTAMP,
    user_id     VARCHAR(50),
    action      VARCHAR(100),
    details     TEXT
);

-- ─────────────────────────────────────────────────────────────
--  VIEWS
-- ─────────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW vw_vehicle_full_details AS
SELECT v.vehicle_id,
       v.registration_number,
       v.make,
       v.model,
       v.year,
       c.customer_id,
       c.name        AS owner_name,
       c.phone       AS owner_phone,
       c.email       AS owner_email
FROM   Vehicle v
LEFT JOIN Customer c ON v.customer_id = c.customer_id;

CREATE OR REPLACE VIEW vw_outstanding_violations AS
SELECT v.violation_id,
       ve.registration_number,
       v.violation_type,
       v.violation_date,
       v.fine_amount,
       v.status
FROM   Violation v
JOIN   Vehicle ve ON ve.vehicle_id = v.vehicle_id
WHERE  v.status = 'Unpaid';

CREATE OR REPLACE VIEW vw_service_history AS
SELECT s.service_id,
       ve.registration_number,
       s.service_date,
       s.service_type,
       s.description,
       s.cost
FROM   ServiceRecord s
JOIN   Vehicle ve ON ve.vehicle_id = s.vehicle_id
ORDER  BY s.service_date DESC;

-- ─────────────────────────────────────────────────────────────
--  STORED PROCEDURES
-- ─────────────────────────────────────────────────────────────

DROP PROCEDURE IF EXISTS sp_add_vehicle(VARCHAR,VARCHAR,VARCHAR,INTEGER,INTEGER);
DROP PROCEDURE IF EXISTS sp_register_service(INTEGER,DATE,VARCHAR,TEXT,NUMERIC);
DROP PROCEDURE IF EXISTS sp_pay_violation(INTEGER);
DROP PROCEDURE IF EXISTS sp_register_user(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);

CREATE OR REPLACE PROCEDURE sp_add_vehicle(
    p_registration  VARCHAR,
    p_make          VARCHAR,
    p_model         VARCHAR,
    p_year          INTEGER,
    p_customer_id   INTEGER
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO Vehicle(registration_number, make, model, year, customer_id)
    VALUES (p_registration, p_make, p_model, p_year, p_customer_id);
END;
$$;

CREATE OR REPLACE PROCEDURE sp_register_service(
    p_vehicle_id    INTEGER,
    p_service_date  DATE,
    p_service_type  VARCHAR,
    p_description   TEXT,
    p_cost          NUMERIC
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO ServiceRecord(vehicle_id, service_date, service_type, description, cost)
    VALUES (p_vehicle_id, p_service_date, p_service_type, p_description, p_cost);
END;
$$;

CREATE OR REPLACE PROCEDURE sp_pay_violation(p_violation_id INTEGER)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE Violation SET status = 'Paid' WHERE violation_id = p_violation_id;
END;
$$;

CREATE OR REPLACE PROCEDURE sp_register_user(
    p_user_id    VARCHAR,
    p_password   VARCHAR,
    p_role       VARCHAR,
    p_full_name  VARCHAR,
    p_address    VARCHAR,
    p_phone      VARCHAR,
    p_email      VARCHAR
)
LANGUAGE plpgsql AS $$
DECLARE
    v_customer_id INTEGER := NULL;
BEGIN
    IF p_role NOT IN ('ADMIN','CUSTOMER','POLICE','INSURANCE','WORKSHOP') THEN
        RAISE EXCEPTION 'Invalid role: %', p_role;
    END IF;

    IF EXISTS (SELECT 1 FROM AppUser WHERE user_id = p_user_id) THEN
        RAISE EXCEPTION 'User ID "%" is already taken.', p_user_id;
    END IF;

    IF p_role = 'CUSTOMER' THEN
        INSERT INTO Customer(name, address, phone, email)
        VALUES (p_full_name, p_address, p_phone, p_email)
        RETURNING customer_id INTO v_customer_id;
    END IF;

    INSERT INTO AppUser(user_id, password, role, full_name, active, customer_id)
    VALUES (p_user_id, p_password, p_role, p_full_name, TRUE, v_customer_id);
END;
$$;

-- ─────────────────────────────────────────────────────────────
--  SEED DATA
-- ─────────────────────────────────────────────────────────────

INSERT INTO Customer(name, address, phone, email) VALUES
('Boitumelo Mpelane',   '12 Kingsway Road, Maseru',              '555-0101', 'boitumelo.mpelane@gmail.com'),
('Mamoshanyana Bolae',  '45 Cathedral Avenue, Maseru',           '555-0102', 'mamoshanyana.bolae@gmail.com'),
('Lineo Nkeane',        '78 Pioneer Road, Maseru',               '555-0103', 'lineo.nkeane@gmail.com'),
('Thabang Letsie',      '23 Moshoeshoe Street, Mafeteng',        '555-0104', 'thabang.letsie@gmail.com'),
('Palesa Mokhethi',     '90 Main North Road, Leribe',            '555-0105', 'palesa.mokhethi@gmail.com'),
('Refiloe Sekhonyana',  '34 Hospital Road, Berea',               '555-0106', 'refiloe.sekhonyana@gmail.com'),
('Tumelo Ramohlokoane', '67 Industrial Area, Maseru',            '555-0107', 'tumelo.ramohlokoane@gmail.com'),
('Nthabiseng Khoaele',  '89 Borokhoaneng, Maseru',               '555-0108', 'nthabiseng.khoaele@gmail.com'),
('Katleho Mphana',      '11 Lithoteng Drive, Maseru',            '555-0109', 'katleho.mphana@gmail.com'),
('Lerato Tlali',        '22 Mohalalitoe Road, Mohale''s Hoek',   '555-0110', 'lerato.tlali@gmail.com');

-- AppUser seed: customer1 links to customer_id=1 (Boitumelo Mpelane)
INSERT INTO AppUser(user_id, password, role, full_name, customer_id) VALUES
('admin',      'admin123',     'ADMIN',     'System Administrator',  NULL),
('workshop1',  'workshop123',  'WORKSHOP',  'Maseru Auto Workshop',  NULL),
('customer1',  'customer123',  'CUSTOMER',  'Boitumelo Mpelane',     1),
('police1',    'police123',    'POLICE',    'Officer Thabo Mokoena', NULL),
('insurance1', 'insurance123', 'INSURANCE', 'SafeDrive Insurance',   NULL);

INSERT INTO Vehicle(registration_number, make, model, year, customer_id) VALUES
('ABC-1001', 'Toyota',     'Corolla',    2020, 1),
('ABC-1002', 'Honda',      'Civic',      2019, 2),
('ABC-1003', 'Ford',       'Focus',      2021, 3),
('ABC-1004', 'Hyundai',    'Elantra',    2018, 4),
('ABC-1005', 'Nissan',     'Sentra',     2022, 5),
('ABC-1006', 'Chevrolet',  'Malibu',     2020, 6),
('ABC-1007', 'Mazda',      'Mazda3',     2019, 7),
('ABC-1008', 'Volkswagen', 'Jetta',      2021, 8),
('ABC-1009', 'Kia',        'Forte',      2022, 9),
('ABC-1010', 'Subaru',     'Impreza',    2020, 10),
('ABC-1011', 'Toyota',     'Camry',      2023, 1),
('ABC-1012', 'Honda',      'Accord',     2022, 2),
('ABC-1013', 'BMW',        '3 Series',   2021, 3),
('ABC-1014', 'Mercedes',   'C-Class',    2020, 4),
('ABC-1015', 'Audi',       'A4',         2019, 5),
('ABC-1016', 'Lexus',      'IS',         2021, 6),
('ABC-1017', 'Acura',      'TLX',        2020, 7),
('ABC-1018', 'Infiniti',   'Q50',        2022, 8),
('ABC-1019', 'Volvo',      'S60',        2021, 9),
('ABC-1020', 'Tesla',      'Model 3',    2023, 10),
('ABC-1021', 'Toyota',     'Highlander', 2022, 1),
('ABC-1022', 'Honda',      'CR-V',       2021, 2),
('ABC-1023', 'Ford',       'Escape',     2020, 3),
('ABC-1024', 'Jeep',       'Cherokee',   2019, 4),
('ABC-1025', 'Mazda',      'CX-5',       2022, 5);

INSERT INTO ServiceRecord(vehicle_id, service_date, service_type, description, cost) VALUES
(1, '2025-01-15', 'Oil Change',    'Standard oil and filter replacement', 75.00),
(2, '2025-02-10', 'Brake Service', 'Front brake pad replacement',         220.50),
(3, '2025-03-05', 'Tire Rotation', 'Rotate and balance all tires',        60.00),
(4, '2025-03-20', 'Battery',       'Replaced 12V battery',                180.00),
(5, '2025-04-01', 'Inspection',    'Annual safety inspection',            45.00),
(6, '2025-04-12', 'Transmission',  'Transmission fluid flush',            210.00),
(1, '2025-04-18', 'Tune Up',       'Spark plugs and air filter',          155.00);

INSERT INTO PoliceReport(vehicle_id, report_date, report_type, description, officer_name) VALUES
(2,  '2025-02-22', 'Accident', 'Minor rear-end collision at Main & 5th', 'Officer Thabo Mokoena'),
(7,  '2025-03-11', 'Theft',    'Vehicle reported stolen, recovered',     'Officer Lebohang Phiri'),
(13, '2025-04-02', 'Accident', 'Side-swipe in parking lot',              'Officer Thabo Mokoena');

INSERT INTO Violation(vehicle_id, violation_date, violation_type, fine_amount, status) VALUES
(1,  '2025-01-08', 'Speeding',     150.00, 'Paid'),
(3,  '2025-02-15', 'Parking',       60.00, 'Unpaid'),
(5,  '2025-03-22', 'Red Light',    200.00, 'Unpaid'),
(8,  '2025-04-05', 'No Insurance', 500.00, 'Unpaid'),
(11, '2025-04-15', 'Speeding',     180.00, 'Paid');

INSERT INTO CustomerQuery(customer_id, vehicle_id, query_date, query_text, response_text) VALUES
(1, 1, '2025-04-01', 'When is my next service due?',    'Recommended after 5,000 km or 6 months.'),
(2, 2, '2025-04-05', 'Brake squeal after replacement.', 'Please book a follow-up inspection.');
